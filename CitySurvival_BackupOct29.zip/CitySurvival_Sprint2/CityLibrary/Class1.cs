﻿using System;
using System.Collections.Generic;

namespace CityLibrary
{
    public class Player
    {
        // Name, HP, Weapon, ItemList
        private string _name;
        private int _hp;
        private int _maxhp;
        private string _weapon;
        private int _room;
        public List<string> Inventory { get; set; }
        public List<Weapon> Weapons { get; set; }
        public List<Potion> Potions { get; set; }

        public Player()
        {
            Name = "Roger";
            HP = 25;
            MaxHP = 25;
            Weapon = "Fist";
            Room = 1;
            Inventory = new List<string>();
            Weapons = new List<Weapon>();
            Potions = new List<Potion>();
        }

        public Player(string name)
        {
            Name = name;
            HP = 25;
            MaxHP = 25;
            Weapon = "Fist";
            Room = 1;
            Inventory = new List<string>();
            Weapons = new List<Weapon>();
            Potions = new List<Potion>();
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        
        public int HP
        {
            get { return _hp; }
            set { _hp = value; }
        }
        public int MaxHP
        {
            get { return _maxhp; }
            set { _maxhp = value; }
        }


        public string Weapon
        {
            get { return _weapon; }
            set { _weapon = value; }
        }

        public int Room
        {
            get { return _room; }
            set { _room = value; }
        }

    }

    public class Thug
    {
        // Name, Type, HP, weapon
        private string _name;
        private string _gangtype;
        private int _hp;
        Weapon _weapon;

        public Thug()
        {
            Name = "Bob";
            GangType = "";
            HP = 0;
            // Alter this when weapons sorted out.
            //Weapon;
        }

        public Thug(string name, string gangType, int hp, Weapon weapon)
        {
            Name = name;
            GangType = gangType;
            HP = hp;
            Weapon = weapon;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string GangType
        {
            get { return _gangtype; }
            set { _gangtype = value; }
        }
        public int HP
        {
            get { return _hp; }
            set { _hp = value; }
        }

        
        public Weapon Weapon
        {
            get { return _weapon; }
            set { _weapon = value; }
        }

        public static Thug InputThug(string name, string gangType, int hp, string weapon)
        {
            Thug output = new Thug();
            output.Name = name;
            output.GangType = gangType;
            output.HP = hp;
            return output;
        }
    }


    //  All of our text objects are stored in [project folder]>[project folder]> bin > Debug

    //
    //
    // Weapon Class


    public class Weapon
    {
        // Name, description, damage maximum (battles are randomized and it's possible to do less damage or miss)
        private string _name;
        private string _description;
        private int _damage;

        public Weapon()
        {
            Name = "Fists";
            Description = "Those things on the ends of your arms.";
            Damage = 3;
        }

        public Weapon(string name, string description, int damage)
        {
            Name = name;
            Description = description;
            Damage = damage;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public int Damage
        {
            get { return _damage; }
            set { _damage = value; }
        }

        public static Weapon InputWeapon(string name, string description, int damage)
        {
            Weapon output = new Weapon();
            output.Name = name;
            output.Description = description;
            output.Damage = damage;
            return output;
        }
    }

    //
    //
    //  Potion Class



    public class Potion
    {
        // Name, Description, Healthboost stat
        private string _name;
        private string _description;
        private int _boost;

        public Potion()
        {
            Name = "";
            Description = "";
            Boost = 0;
        }

        public Potion(string name, string description, int boost)
        {
            Name = name;
            Description = description;
            Boost = boost;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public int Boost
        {
            get { return _boost; }
            set { _boost = value; }
        }

        public static Potion InputPotion(string name, string description, int boost)
        {
            Potion output = new Potion();
            output.Name = name;
            output.Description = description;
            output.Boost = boost;
            return output;
        }

    }


}
