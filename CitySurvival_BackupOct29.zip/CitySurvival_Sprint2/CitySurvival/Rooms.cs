﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;
using System.IO;

namespace CitySurvival
{
    public class Rooms
    {
        //
        //
        //
        //  Loading in all of the potion, weapon, and thug objects
        //  It's just convenient to put it here rather than elsewhere.

        public static void LoadAll()
        {
            try
            {
                StreamReader inputFile;

                inputFile = File.OpenText("weapons.txt");
                CityLibrary.Weapon output = new CityLibrary.Weapon();

                string name;
                string description;
                int damage;
                while (!inputFile.EndOfStream)
                {
                    name = inputFile.ReadLine();
                    description = inputFile.ReadLine();
                    damage = int.Parse(inputFile.ReadLine());
                    output = CityLibrary.Weapon.InputWeapon(name, description,damage);
                }


                inputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        

        //
        //
        //
        //   The Bakery is a safe location, never get attacked.

        public static Player Bakery(Player player)
        {
            bool getout = false;
            string action;

            Console.WriteLine("\n");
            Text.BakeryLook();
            Console.WriteLine("- North.");
            Console.WriteLine("- East.");
            Console.WriteLine("- \n");

            while (!getout)
            {

                action = Console.ReadLine();

                if (action.ToLower().Contains("take a shower") || action.ToLower().Contains("shower"))
                {
                    Text.Showers();
                }
                else if (action.ToLower().Contains("look cabinets") || action.ToLower().Contains("cabinets") || action.ToLower().Contains("search cabinets"))
                {
                    Text.Cabinets(player);
                }
                else if (action.ToLower().Contains("search rubbish") || action.ToLower().Contains("looks rubbish"))
                {
                    Text.Rubbish();
                }
                else if (action.ToLower().Contains("north"))
                {
                    Console.WriteLine("\nYou open the door and go north.");
                    player.Room = 14;
                }
                else if (action.ToLower().Contains("east"))
                {
                    Console.WriteLine("\nYou walk east through the open door.");
                    player.Room = 16;
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("Look"))
                {
                    Text.BakeryLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }

            return player;
        }


        //
        //
        //
        //
        //
        //  Up ahead are the bank locations


        public static Player BankLobby(Player player)
        {
            bool getout = false;
            string action;

            Console.WriteLine("\n");
            Text.BankLobbyLook();
            Console.WriteLine("- North.");
            Console.WriteLine("- Northeast.");
            Console.WriteLine("- West.");
            Console.WriteLine("- \n");

            while (!getout)
            {
              
                action = Console.ReadLine();

                if (action.ToLower().Contains("look barrier"))
                {
                    Text.LookBarrier();
                }
                else if (action.ToLower().Contains("take barrier") || action.ToLower().Contains("get barrier"))
                {
                    Text.TakeBarrier();
                }
                else if (action.ToLower().Contains("search rummage") || action.ToLower().Contains("rummage"))
                {
                    Text.LookRummage();
                }
                else if (action.ToLower().Contains("look at counter") || action.ToLower().Contains("look counter"))
                {
                    Text.LookCounter();
                    player.Inventory.Add("pen");
                }
                else if (action.ToLower().Contains("look behind counter"))
                {
                    Text.LookBehindCounter();
                    if (!player.Inventory.Contains("pen"))
                    {
                        Text.LookBehindCounter2();
                    }
                }
                else if (action.ToLower().Contains("look out of window") || action.ToLower().Contains("Look out window") || action.ToLower().Contains("Look window"))
                {
                    Text.LookBankWindow();
                }
                else if (action.ToLower().Contains("look adverts") || action.ToLower().Contains("adverts") || action.ToLower().Contains("look ads"))
                {
                    Text.LookAdverts();
                }
                else if (action.ToLower().Contains("take adverts") || action.ToLower().Contains("take ads"))
                {
                    Text.DontWant();
                }
                else if (action.ToLower().Contains("north"))
                {
                    Console.WriteLine("\nYou head north into the bank's office.");
                    player.Room = 3;
                }
                else if (action.ToLower().Contains("northeast") || action.ToLower().Contains("east"))
                {
                    Console.WriteLine("\nYou go northeast into the bank vault.");
                    player.Room = 4;
                }
                else if (action.ToLower().Contains("west"))
                {
                    Console.WriteLine("\nYou leave the building.");
                    player.Room = 13;
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("Look"))
                {
                    Text.BankLobbyLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }


                return player;
        }
        public static Player BankOffice(Player player)
        {
            bool getout = false;
            string action;

            Console.WriteLine("\n");
            Text.BankOfficeLook();
            Console.WriteLine("- South.");
            Console.WriteLine("- \n");

            while (!getout)
            {
                action = Console.ReadLine();

                if(action.ToLower().Contains("look out of the window")  || action.ToLower().Contains("look window"))
                {
                    Text.LookOfficeWindow();
                }
                else if (action.ToLower().Contains("look desk"))
                {
                    Text.LookDesk();
                }
                else if (action.ToLower().Contains("take papers"))
                {
                    Text.TakePapers();
                    player.Inventory.Add("paper");
                }
                else if (action.ToLower().Contains("read poem"))
                {
                    Text.ReadPoem();
                }
                else if (action.ToLower().Contains("look chair") || action.ToLower().Contains("search chair"))
                {
                    Text.LookOfficeChair();
                }
                else if (action.ToLower().Contains("take chair"))
                {
                    Text.DontWant();
                }
                else if (action.ToLower().Contains("take cigarette butts"))
                {
                    Text.DontWant();
                }
                else if (action.ToLower().Contains("search stuffing") || action.ToLower().Contains("take stuffing") || action.ToLower().Contains("look stuffing"))
                {
                    Text.TakeStuffing();
                    player.Inventory.Add("chair stuffing");
                    // Add cigarettes to inventory here when system figured out.
                }
                else if (action.ToLower().Contains("south"))
                {
                    Console.WriteLine("\nYou head back south into the bank lobby.");
                    player.Room = 2;
                }
            /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("Look"))
                {
                    Text.BankOfficeLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }
        public static Player BankVault(Player player)
        {
            bool getout = false;
            string action;
            Console.WriteLine("\n");
            Text.BankVaultLook();
            Console.WriteLine("- South.");
            Console.WriteLine("- \n");

            while (!getout)
            {
                action = Console.ReadLine();

                if (action.ToLower().Contains("search vault") || action.ToLower().Contains("look vault")) 
                {
                    if (player.Inventory.Contains("flashlight"))
                    {
                        Text.VaultSearchLight();
                        var random = new Random();
                        int doof = random.Next(100);
                        if(doof> 65)
                        {
                            Console.WriteLine("Cool, you found some food.");
                            // Add food to player.Potions when inventory figured out.
                        }
                    }
                    else
                    {
                        Text.VaultSearch();
                        var random = new Random();
                        int doof = random.Next(100);
                        if (doof > 90)
                        {
                            Console.WriteLine("Cool, you found some food.");
                            // Add food to player.Potions when inventory figured out.
                        }
                    }
                }
                else if (action.ToLower().Contains("go south"))
                {
                    Console.WriteLine("You go south and leave the vault.");
                    player.Room = 2;
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look") && player.Inventory.Contains("flashlight"))
                {
                    Text.BankVaultLookLight();
                }
                else if (action.ToLower().Contains("Look"))
                {
                    Text.BankVaultLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }

        public static Player HotelLobby(Player player)
        {
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player HotelBallroom(Player player)
        {
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }
        public static Player HotelStairwell(Player player)
        {
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside1(Player player)
        {
            // In front of boss doors, top left
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside2(Player player)
        {
            // ruins of old coffee shop, top center
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside3(Player player)
        {
            // upper right corner of block, dangerous gangs, only left, down
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside4(Player player)
        {
            // back alley behind hotel
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside5(Player player)
        {
            // lower back alley behind hotel
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside6(Player player)
        {
            // between the hotel and the bank
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside7(Player player)
        {
            // Area above old bakery, left side of map
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside8(Player player)
        {
            // Alley behind old bakery, bottom left corner of map
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside9(Player player)
        {
            // Large area east of bakery, bottom center of map
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside10(Player player)
        {
            // Large area further east of bakery, in front of pizzaria, bottom center of map
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Outside11(Player player)
        {
            // Alley just below the pizzaria, bottom right corner of map
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player Pizzaria(Player player)
        {
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player PizzariaOffice(Player player)
        {
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player AnimalControl1(Player player)
        {
            // Gang hangout
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

        public static Player AnimalControl2(Player player)
        {
            // Big Boss Room
            bool getout = false;
            string action;

            while (!getout)
            { }
            return player;
        }

    }
}
