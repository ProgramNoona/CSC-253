﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;


namespace CitySurvival
{
    public class Text
    {
        //
        // Utility  or battle functions for player, should be available for all rooms. 
        //
        //
        public static void LookInventory(Player player)
        {
            Console.Write("Here is your inventory:  ");
            for (int i = 0; i<player.Inventory.Count; i++)
            {
                if (i == player.Inventory.Count - 1)
                {
                    Console.WriteLine($"{player.Inventory[i]}\n");
                }
                else
                {
                    Console.Write($"{player.Inventory[i]}, ");
                }
            }

            Console.WriteLine("\nHere are your healing items: ");
            foreach (Potion booster in player.Potions)
            {
                Console.WriteLine($"{booster.Name}:  {booster.Description}.");
            }

            Console.WriteLine("\nHere are your weapons: ");
            foreach (Weapon fight in player.Weapons)
            {
                Console.WriteLine($"{fight.Name}:  {fight.Description}");
            }
        }
        
        public static void Help()
        {
            Console.WriteLine("\n Help Text -- ");
            Console.WriteLine("The listed options for a given room are not the only actions you can take.  You can \'look\' and \'search\' all important" +
                "items or areas.  Capitalization does not matter.  ");
            Console.WriteLine("Some of your items are helpful, the others are just for fun.");
            // This is all I could think of for now, adding more help text when issues pop up.
        }

        //
        //  This is used as test dialogue for any item that a player might want to pick up, but isn't pickupable.
        public static void DontWant()
        {
            var random = new Random();
            int message = random.Next(10);

            switch (message)
            {
                case 0:
                    Console.WriteLine("\nI don't see why you would want that.");
                    break;
                case 1:
                    Console.WriteLine("\nBut why?");
                    break;
                case 2:
                    Console.WriteLine("\nThat's not useful to you now.");
                    break;
                case 3:
                    Console.WriteLine("\nCan't you just leave it alone?");
                    break;
                case 4:
                    Console.WriteLine("\nNah, you don't want that.");
                    break;
                case 5:
                    Console.WriteLine("\nIt's not important.");
                    break;
                case 6:
                    Console.WriteLine("\nIt doesn't look appealing");
                    break;
                case 7:
                    Console.WriteLine("\nNo, not right now.  Or ever, really.");
                    break;
                case 8:
                    Console.WriteLine("\nThis item is only here to look good.");
                    break;
                case 9:
                    Console.WriteLine("\nYou don't need every item you see.");
                    break;
                default:
                    Console.WriteLine("...Something has gone wrong with the code.  Check Text.DontWant().");
                    break;
            }


        }

        // Battle program for generic battles.
        public static Player BattleTime(Player player)
        {
            // put stuff here when you figure out how to do battles
            return player;
        }







        //
        //
        // Room specific text goes below here.
        //
        //




        //
        //
        // The bakery
        public static void BakeryLook()
        {
            Console.WriteLine("\nYou are in the remains of what was once an old bakery.  Against the south wall is a large pile of soft-ish rubbish, " +
                "mainly meant for sleeping.  To the west are a few cabinets, generally only containing things not worth stealing.  Exit doors fit " +
                "into the north and east walls.  In the northeast corner is a makeshift shower made from a few old hoses and coffee cans.  ");
        }
        public static Player Cabinets(Player player)
        {
            Console.WriteLine("You search through the cabinets only casually.  It wouldn't do to look too eager to search through other people's " +
                "belongings.  Most of the cabinets still have doors, and those that don't are generally empty of all but greasy rags or other detritus.");

            // temporary item until items have been worked out
            if (player.Inventory.Contains("hammer"))
            {
                Console.WriteLine("You search the cabinet that is more or less yours.  It's still got the old random junk in it.  No surprises.");
            }
            else
            {
                Console.WriteLine("One specific cabinet is more or less yours.  You've been putting random items in it so that the randos in here " +
                    "get used to the idea that it's yours.  Mainly you put in it random junk -- the arms of broken action figures, paperclips, broken " +
                    "pottery -- anything to suggest that you're some eclectic who likes things not worth owning.  You search through it, and find that " +
                    "one of the items actually is useful.");
                // insert item getting code here
                // player.Inventory.Add(hammer);
                return player;
            }
            return player;
        }
        public static void Showers()
        {
            Console.WriteLine("You're not terribly shy about showering in front of the guys in the bakery -- as a rule, nobody stares -- but it's nice " +
                "to have shower curtains anyway.  Actual curtains, that is, strung about with some old fishing line.  You push past the fabric and check " +
                "behind the jerry-rigged shower.  Aw great, they didn't fill up the water tanks.  Lovely.  Good thing you checked before taking off your" +
                "clothes. ");
        }

        public static void Rubbish()
        {
            Console.WriteLine("You search through the pile of rags and tattered furniture bits that are not currently covered by the sleeping or " +
                "resting.  As you expect, there's nothing you need.");
        }






        //
        //
        //  The bank Lobby

        public static void BankLobbyLook()
        {
            Console.WriteLine("This is the lobby of a long since defunct bank.  Careful examination of the walls would reveal the last remains" +
                "of the retirement savings adverts.  To the north is a door to an office.  Curving around the northeast corner of the lobby is a bank counter, " +
                "chipped and faded with age and bullets.  It leads to a vault in the back.  Before this counter is old velvet barrier remains, as well as " +
                "various rummage strewn about the floor.  There's a window to the south.  To the west is the door from which you came.");
        }
        public static void BLBattleText()
        {
            // This exists as room-specific flavortext for when battle starts.  It is does not the handle actual battles.
            Console.WriteLine("Battle flavor text for this room has not yet been written");
        }
        public static void LookBarrier()
        {
            Console.WriteLine("\nThe old velvet barrier that now lies rotting on the floor was apparently used to help people line up for service in the bank.  " +
                "So you were told.  You were too young to have a bank account when everything changed, so you're not sure.  It's hard to imagine people ever waiting " +
                "in a line these days, though.");
        }
        public static void TakeBarrier()
        {
            Console.WriteLine("\nAs you kneel to get closer to the velvet barriers, that's when you notice the smell.  Just in time to stop yourself from actually " +
                "touching the fabric, you see aged spots of greenish-grey mold decorating the back and underside of the rope.  You pull back your hand and " +
                "straighten, trying not to think about how nasty actually touching it would have been.");
        }
        public static void LookRummage()
        {
            Console.WriteLine("\nThere sure is a lot of garbage around this place.  It seems to be primarily old beer cans, dirty needles, and broken glass.  " +
                "In other words, it has nothing that you really want.  Well, if you had a gun, you could use all the discarded shell casings to make your own " +
                "bullets.");
        }
        public static void LookCounter()
        {
            Console.WriteLine("\nWell, it's a counter alright.  The gun-damaged wall behind it was apparently not the only thing used for target practice.  The " +
                "counter's outer sill is also shot up.  If you wanted to, you could pick out some lead from all the old bullets in it.  The one good thing about the " +
                "Mange taking control of all weaponry in this sector to fight outsiders is that these impulsive gun games are a lot less common.");
        }
        public static void LookBehindCounter()
        {
            Console.WriteLine("\nOh wow, it's really a mess back here.  Broken glass and discarded cans everywhere.  You'd figure that the Mange would have one of " +
                "their lackeys clean up a bit, if only so that they can have target practice again.");
        }
        public static void LookBehindCounter2()
        {
            Console.WriteLine("\tOh look, a pen.  You pick it up.  Never know when that might come in handy.");
        }
        public static void LookBankWindow()
        {
            Console.WriteLine("\nYou look out of the window, but there isn't much to see.  It's just a bare patch of sky visible over the wall pressed up against the " +
                "outside of the bank.  Nobody's really sure why the wall is there.  The window it blocks is broken, but nobody has bothered to graffiti this side of the " +
                "wall.  It's a good thing that this bank has skylights, or else nothing inside would be visible.");
        }
        public static void LookAdverts()
        {
            Console.WriteLine("\nYou look up at the advertisements on the wall.  Behind the plastic and grime are pictures of very happy-looking people posing.  " +
                "Their faces have long since been scribbled over with various marks and slogans, the largest of which says \"Rage the Mange\".  You're not " +
                "sure what that's supposed to mean. The images behind the counter seem to have been used for target practice, so their images are lost to time." +
                "\n\tThe largest and hardest to reach advert (and thus least defaced) is one of an elderly couple in a boat.  " +
                "The direct, wide angle of the picture makes it look like they're somehow flying their motorboat up out of the water.  You wish that you could fly " +
                "away from here, even if in a ridiculous apparatus.");
        }


        //
        //
        // The bank office
        public static void BankOfficeLook()
        {
            Console.WriteLine("The old office is messier than usual.  You know that people come in here from time to time, judging from all the old cigarette butts " +
                "on the floor.  There's a beat up old desk, and likewise a couple of much abused old office chairs.  A window to the west casts a smoky light across the " +
                "room.  The only exit is the way you came, to the south.");
        }
        public static void BOBattleText()
        {
            // This exists as room-specific flavortext for when battle starts.  It is does not the handle actual battles.
            Console.WriteLine("Battle flavor text for this room has not yet been written");
        }
        public static void LookOfficeWindow()
        {
            Console.WriteLine("You peek a little sideways out of the window.  You see a roving thug or two, but they aren't paying you any attention.  Even if they were, " +
                "it's not easy to see much through the dirty window.  Still, you are able to see the street, and primarily the hotel across it.  Not the best view.");
        }
        public static void LookDesk()
        {
            // Add a packet of cigarettes here when the inventory system is figured out. 
            Console.WriteLine("There isn't much in the desk, aside from a few papers.  You're not really sure why, but it looks like one of the thugs has kept some of " +
                "the bank's papers.  Most of them are yellowed with age, and you find it difficult to understand what they're supposed to mean.  The paper on top says " +
                "\"September Statement\" and then lists various things with monetary units on the side.  Huh, these must technically be artifacts in this day and " +
                "age.");
        }
        public static void TakePapers()
        {
            Console.WriteLine("Well, alright.  You take the odd papers out of the desk and stash them on your person.  Huh, there's something written on the back of " +
                "one of these papers.  It looks like a poem.");
        }
        public static void ReadPoem()
        {
            Console.WriteLine("You read the poem: ");
            Console.WriteLine("\n\tStreets stretch out to follow the wind");
            Console.WriteLine("\tThe wind flies on, passing them by");
            Console.WriteLine("\tStationary lines of tar imitate");
            Console.WriteLine("\tBut they will never reach a sky.");
            Console.WriteLine("\tI too march with these streets");
            Console.WriteLine("\tGun and I, we tell their same lie.");
            Console.WriteLine("\nWow, that was, uh...something else.");
        }
        public static void LookOfficeChair()
        {
            Console.WriteLine("\nThis chair used to be fancy.  Actually, it's still pretty fancy.  It smells of cigarette smoke, but the cushion's stuffing is only " +
                "poking out from the lower left side.  You sit in the chair for a bit to rest.  Yep, pretty comfy.");
        }
        public static void TakeStuffing()
        {
            // add cigarette here when inventory figured out. 
            Console.WriteLine("\nFor some reason, you decide to take out the stuffing.  What's this?  Oh, someone stashed a couple of cigarettes.  Nice.");
        }
        


        //
        //
        // The bank vault
        public static void BankVaultLook()
        {
            Console.WriteLine("The vault has long since been completely looted.  All of the deposit boxes are various degrees of open and empty, at least to the " +
                "casual glance.  It's too dark in here for you to do much in the way of looking.  The only exit is south.");
        }
        public static void VaultSearch()
        {
            Console.WriteLine("You search the vault for a while, but it's pretty annoying to do without a light source.  Particularly since there's some broken " +
                "glass on the bottom of the floor.  You search for a bit, but give up pretty quickly.");
        }
        public static void VaultSearchLight()
        {
            Console.WriteLine("You search the vault for a while.  It's a little easier with a flashlight, but there's literally deposit boxes left, right, and center, " +
                "from the floor to the ceiling.  You don't want to be here all day.  You search for a bit, then stop.");
        }
        public static void BankVaultLookLight()
        {
            Console.WriteLine("The vault has long since been completely looted.  All of the deposit boxes are various degrees of open and empty, at least to the " +
                "casual wave of your flashlight.  A metal...block...thing sits in the middle of the room.  It's apparently used to serve as a table, back when the " +
                "city was its old self.  You can barely remember those old days.  The only exit is south.");
        }

        // No battling in the vault.  Dealing with the darkness aspect of fighting is just too much for one semester project.
        //
        //public static void BVBattleText()
        //{
        //    // This exists as room-specific flavortext for when battle starts.  It is does not the handle actual battles.
        //    Console.WriteLine("Battle flavor text for this room has not yet been written");
        //}
    }
}
