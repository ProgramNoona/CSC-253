﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;

namespace CitySurvival
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;
			
            string status = "playing";

            // Load all the objects/baddies
            LoadingLists.LoadAll();


            string playerName;
            Console.WriteLine("Enter your name, Stranger");
            playerName = Console.ReadLine();


            //create player object
            CityLibrary.Player player = new Player(playerName);

            Console.WriteLine($"Hello, {player.Name}.");
            Console.WriteLine("You wake up, as you do, in the old, rundown bakery that has been your home for " +
                "the past eighteen months.  Well, yours and about a half dozen other people.  This whole block has " +
                "been the bastion of a gang called \'the Mange\', and for the time being they're not letting anyone " +
                "out.  They haven't said why, but the gunfire on the outside of their little locality makes it pretty " +
                "obvious that they don't consider it safe.  You'd almost think that Mange is concerned for the welfare " +
                "of the locals, except for the fact that you don't know who they're opposing, or even if this " +
                "opposition has weaponry of their own.  The Mange might be fighting them off to keep them from " +
                "getting local supplies.");
            Console.WriteLine("As much as this concerns you, the fact is whatever lies outside is a mystery.  What's " +
                "crystal clear is the fact that the Mange are extremely dangerous, and if traffic with the outside " +
                "doesn't resume, you'll all starve.  You don't plan on being one of those people.");
            Console.ReadLine();

            Console.WriteLine("You stretch against the stiffness in your bones and rise from the pile of rubbish that constitutes" +
                "your bed.  It's a big pile of rubbish, so it's also the bed of five other stragglers, three of which are still " +
                "resting there.");
            Console.WriteLine("\'Okay,\' you tell yourself.  \'Let's get to business\'.");

 

            while (program)
            {
                if (player.Room == 1)
                {
                    Rooms.Bakery(player);
                }
                else if (player.Room == 2)
                {
                    Rooms.BankLobby(player);
                }
                else if (player.Room == 3)
                {
                    Rooms.BankOffice(player);
                }
                else if (player.Room == 4)
                {
                    Rooms.BankVault(player);
                }
                else if (player.Room == 5)
                {
                    Rooms.HotelLobby(player);
                }
                else if(player.Room == 6)
                {
                    Rooms.HotelBallroom(player);
                }
				
				// 
                //
                // This room has been eliminated from the game due to time constraints.  Here for reference.
                //else if (player.Room == 7)
                //{
                //    Rooms.HotelStairwell(player);
                //}

                // Room outside of Animal Hospital, top left of map
                else if (player.Room == 8)
                {
                    Rooms.Outside1(player);
                }

                // Area with ruined remains of cafe, top center of map
                else if(player.Room == 9)
                {
                    Rooms.Outside2(player);
                }

                // Area east of cafe remains, top right of map
                else if (player.Room == 10)
                {
                    Rooms.Outside3(player);
                }


                //  Room removed for time constraint reasons.
                //
                //// Upper alley behind hotel, left side of map
                //else if (player.Room == 11)
                //{
                //    Rooms.Outside4(player);
                //}

                // Lower alley behind hotel, left side of map
                else if (player.Room == 12)
                {
                    Rooms.Outside5(player);
                }

                // Road between hotel and bar, center of map
                else if (player.Room == 13)
                {
                    Rooms.Outside6(player);
                }

                // Area above old bakery, left side of map
                else if (player.Room == 14)
                {
                    Rooms.Outside7(player);
                }


                //  Room removed for time constraint reasons
                //
                // Alley behind old bakery, bottom left corner of map
                //else if (player.Room == 15)
                //{
                //    Rooms.Outside8(player);
                //}

                // Large area east of bakery, bottom center of map
                else if (player.Room == 16)
                {
                    Rooms.Outside9(player);
                }

                // Room removed for time constraint reasons, merged with z9
                //
                // Large area further east of bakery, in front of pizzaria, bottom center of map
                //else if (player.Room == 17)
                //{
                //    Rooms.Outside10(player);
                //}

                // Room Removed for time constraints.
                //
                // Alley just below the pizzaria, bottom right corner of map
                //else if (player.Room == 18)
                //{
                //    Rooms.Outside11(player);
                //}

                else if (player.Room == 19)
                {
                    Rooms.Pizzaria(player);
                }

                // Room Removed for time constraints.
                //
                //else if (player.Room == 20)
                //{
                //    // 
                //    //
                //    // This room has been eliminated from the game due to time constraints.  Here for reference.
                //    Rooms.PizzariaOffice(player);
                //}
                else if (player.Room == 21)
                {
                    Rooms.AnimalControl1(player);
                }
                // Room Removed for time constraints.
                //
                //else if (player.Room == 22)
                //{
                //    Rooms.AnimalControl2(player);
                //}
                else if (player.Room == 144)
                {
                    status = "won";
                }
                else
                {
                    status = "lost";
                }
            }

            // Winning and losing conditions go here
            if (status== "won")
            {
                Console.WriteLine("\nYou open the door to the animal hospital, pulling the helmet over your head.  The way seems clear now, as the Mange left " +
                    "behind a little pathway between high stacks of rubble.  You hear gunblasts in the distance, but for now you're not visible.  You move forward, " +
                    "not knowing what you will face.  Your only plan is to get clear of the Mange's territory and find a way to speak to someone from the outside.  " +
                    "Only then will you be able to make a future for yourself.  At the same time, a rush of adrenaline fills you.  Even in the midst of the danger, " +
                    "it feels like the future is now.");

                Console.WriteLine("\nCongratulations.  You have escaped.");
				program = false;
            }
            else if (status == "lost")
            {
				if(player.Room ==600)
				{
					Console.WriteLine($"Not everyone wants to be your friend, {player.Name}.  Better luck next time.");
				}
				else if(player.Room == 601)
				{
					Console.WriteLine($"Sorry, {player.Name}, but you can't say I didn't warn you.");
				}
                else if(player.Room == 602)
                {
                    Console.WriteLine($"Don't blame me, {player.Name}.  You're the one that wanted to climb the barrier.");
                }
                else if(player.Room == 603)
                {
                    Console.WriteLine($"I'm sorry, {player.Name}, but it was your choice to cross that street.");
                }
                else if (player.Room == 604)
                {
                    Console.WriteLine($"Sorry.  Should've been stronger before facing Connor Gunner.");
                }
                else
                {
                    // This is for any generic death that happens in a random battle.
                    Console.WriteLine($"Here lies {player.Name}, dead on the street.");
                }
				
				Console.Write("\nTry again? (yes or no): ");
				status = Console.ReadLine();
				if(status.ToLower().Contains("no") || status.ToLower() == "n")
				{
					Console.WriteLine("Thanks for playing!");
					program =false;
				}
				
            }
        }
    }
}
