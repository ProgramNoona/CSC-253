﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;
using System.IO;

namespace CitySurvival
{
    public class Rooms
    {
        //
        //
        //
        //   The Bakery is a safe location, never get attacked.
        
        public static Player Bakery(Player player)
        {
            bool getout = false;
            string action;
            


            Console.WriteLine("\n");
            Text.BakeryLook();
            Console.WriteLine("- East.");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("take a shower") || action.ToLower().Contains("shower"))
                {
                    Text.Showers();
                }
                else if (action.ToLower().Contains("look cabinets") || action.ToLower().Contains("cabinets") || action.ToLower().Contains("search cabinets"))
                {
                    Text.Cabinets(player);
                }
                else if (action.ToLower().Contains("search rubbish") || action.ToLower().Contains("looks rubbish"))
                {
                    Text.Rubbish();
                }
                else if (action.ToLower().Contains("north"))
                {
                    Console.WriteLine("\nYou open the door and go north.");
                    player.Room = 14;
					getout = true;
                }
                else if (action.ToLower().Contains("east"))
                {
                    Console.WriteLine("\nYou walk east through the open door.");
                    player.Room = 16;
					getout = true;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.BakeryLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood."); ;
                }
            }

            return player;
        }


        //
        //
        //
        //
        //
        //  Up ahead are the bank locations


        public static Player BankLobby(Player player)
        {
            bool getout = false;
            string action;
            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Console.WriteLine("\n");
            Text.BankLobbyLook();
            Console.WriteLine("- North.");
            Console.WriteLine("- Northeast.");
            Console.WriteLine("- West.");
            Console.WriteLine("- \n");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("look barrier"))
                {
                    Text.LookBarrier();
                }
                else if (action.ToLower().Contains("take barrier") || action.ToLower().Contains("get barrier"))
                {
                    Text.TakeBarrier();
                }
                else if (action.ToLower().Contains("search rummage") || action.ToLower().Contains("rummage"))
                {
                    Text.LookRummage();
                }
                else if (action.ToLower().Contains("look at counter") || action.ToLower().Contains("look counter"))
                {
                    Text.LookCounter();
                    player.Inventory.Add("pen");
                }
                else if (action.ToLower().Contains("look behind counter"))
                {
                    Text.LookBehindCounter();
                    if (!player.Inventory.Contains("pen"))
                    {
                        Text.LookBehindCounter2();
                    }
                }
                else if (action.ToLower().Contains("look out of window") || action.ToLower().Contains("Look out window") || action.ToLower().Contains("Look window"))
                {
                    Text.LookBankWindow();
                }
                else if (action.ToLower().Contains("look adverts") || action.ToLower().Contains("adverts") || action.ToLower().Contains("look ads"))
                {
                    Text.LookAdverts();
                }
                else if (action.ToLower().Contains("take adverts") || action.ToLower().Contains("take ads"))
                {
                    Text.DontWant();
                }
                else if (action.ToLower().Contains("north"))
                {
                    Console.WriteLine("\nYou head north into the bank's office.");
                    player.Room = 3;
					getout = true;
                }
                else if (action.ToLower().Contains("northeast") || action.ToLower().Contains("east"))
                {
                    Console.WriteLine("\nYou go northeast into the bank vault.");
                    player.Room = 4;
					getout = true;
                }
                else if (action.ToLower().Contains("west"))
                {
                    Console.WriteLine("\nYou leave the building.");
                    player.Room = 13;
					getout = true;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.BankLobbyLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }


                return player;
        }
        public static Player BankOffice(Player player)
        {
            bool getout = false;
            string action;
            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Console.WriteLine("\n");
            Text.BankOfficeLook();
            Console.WriteLine("- South.");
            Console.WriteLine("- \n");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if(action.ToLower().Contains("look out of the window")  || action.ToLower().Contains("look window"))
                {
                    Text.LookOfficeWindow();
                }
                else if (action.ToLower().Contains("look desk"))
                {
                    Text.LookDesk();
                }
                else if (action.ToLower().Contains("take papers"))
                {
                    Text.TakePapers();
                    player.Inventory.Add("paper");
                }
                else if (action.ToLower().Contains("read poem"))
                {
                    Text.ReadPoem();
                }
                else if (action.ToLower().Contains("look chair") || action.ToLower().Contains("search chair"))
                {
                    Text.LookOfficeChair();
                }
                else if (action.ToLower().Contains("take chair"))
                {
                    Text.DontWant();
                }
                else if (action.ToLower().Contains("take cigarette butts"))
                {
                    Text.DontWant();
                }
                else if (action.ToLower().Contains("search stuffing") || action.ToLower().Contains("take stuffing") || action.ToLower().Contains("look stuffing"))
                {
                    Text.TakeStuffing();
                    player.Inventory.Add("chair stuffing");
                    // Add cigarettes to inventory here when system figured out.
                }
                else if (action.ToLower().Contains("south"))
                {
                    Console.WriteLine("\nYou head back south into the bank lobby.");
                    player.Room = 2;
					getout = true;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.BankOfficeLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }
        public static Player BankVault(Player player)
        {
            bool getout = false;
            string action;
            Console.WriteLine("\n");
            Text.BankVaultLook();
            Console.WriteLine("- South.");
            Console.WriteLine("- \n");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("search vault") || action.ToLower().Contains("look vault")) 
                {
                    if (player.Inventory.Contains("flashlight"))
                    {
                        Text.VaultSearchLight();
                        var random = new Random();
                        int doof = random.Next(100);
                        if(doof> 65)
                        {
                            Console.WriteLine("Cool, you found some food.");
                            // Add food to player.Potions when inventory figured out.
                        }
                    }
                    else
                    {
                        Text.VaultSearch();
                        var random = new Random();
                        int doof = random.Next(100);
                        if (doof > 90)
                        {
                            Console.WriteLine("Cool, you found some food.");
                            // Add food to player.Potions when inventory figured out.
                        }
                    }
                }
                else if (action.ToLower().Contains("go south"))
                {
                    Console.WriteLine("You go south and leave the vault.");
                    player.Room = 2;
					getout = true;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look") && player.Inventory.Contains("flashlight"))
                {
                    Text.BankVaultLookLight();
                }
                else if (action.ToLower().Contains("look"))
                {
                    Text.BankVaultLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }
        public static Player HotelLobby(Player player)
        {
            bool getout = false;
            string action;
			int annoyed = 0;
			bool looked = false;
			bool warned = false;
            Console.WriteLine("\n");
            Text.HotelLobbyLook();
            Console.WriteLine("- East.");
            Console.WriteLine("- North.");
            Console.WriteLine("- West.");
            Console.WriteLine("- \n");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("look stairwell")|| action.ToLower().Contains("look stairs"))
                {
					Text.StairsLook();
                }
                else if (action.ToLower().Contains("talk guards") || action.ToLower().Contains("talk guys")  || action.ToLower().Contains("say"))
                {
					if(annoyed ==2)
					{
						Text.PissedOff();
						player.Room = 600;
						getout =true;
					}
					else if(annoyed ==1)
					{
						Text.AlmostPissed();
						annoyed +=1;
					}
					else
					{
						Text.Irritated();
						annoyed +=1;
					}
                }
                else if (action.ToLower().Contains("look carpet"))
                {
					Text.LookCarpet();
                }
                else if (action.ToLower().Contains("look plant"))
                {
					Text.LookPlant();
					if(!looked)
					{
						Text.LookPlantA();
						player.Cigarettes += 2;
						looked = true;
					}
					else
					{
						Text.LookPlantB();
					}
                }
				else if (action.ToLower().Contains("take plant") || action.ToLower().Contains("get plant"))
				{
					Text.DontWant();
				}
                else if (action.ToLower().Contains("go north") || action.ToLower().Contains("north") || action.ToLower().Contains("ballroom"))
                {
					Console.WriteLine("\nYou enter the hotel's ballroom.");
					player.Room = 6;
					getout =true;
                }
                else if (action.ToLower().Contains("go west") || action.ToLower().Contains("go up stairs"))
                {
					if(!warned)
					{
						Console.WriteLine($"\nUm, {player.Name}, do you really want to go up those stairs?  They're being guarded by a couple of scary looking hombres.  " +
						"You're pretty sure they don't want you up there.  At least, the fact that they have actual firearms would seem to say so.");	
					}
					else
					{
						Text.GoUpstairs();
						player.Room = 601;
						getout =true;
					}
                }
                else if (action.ToLower().Contains("go east"))
                {
                    Console.WriteLine("You exit the door and go back out into the street.");
					getout =true;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.HotelLobbyLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }

		
		//
		//
		//  Code for the Hotel's Ballroom
        //  buy food, sell food, buy the bat here
        //  I'll come for this later.
        public static Player HotelBallroom(Player player)
        {
            bool getout = false;
            string action;

            while (!getout)
            {
                Console.WriteLine("\n");
            }
            return player;
        }


        //
        //
        //  Code for the Hotel's Ballroom
        //  buy food, sell food, buy the bat here
        //  I'll come for this later.
        public static Player HotelBallroom(Player player)
        {
            bool getout = false;
            string action;

            Text.HotelBallroomLook();
            Console.WriteLine("- South");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("talk"))
                {
                    Text.TalkBlueHat();
                }
                else if (action.ToLower().Contains("go south"))
                {
                    Console.WriteLine("You exit the ballroom.");
                    getout = true;
                    player.Room = 5;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.HotelBallroomLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }







        //
        //
        //  Area right in front of boss doors/Animal hospital, Z1 on map, player.Room == 8

        public static Player Outside1(Player player)
        {
            // In front of boss doors, top left
            bool getout = false;
            bool warned = false;
            string action;
            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Text.MapZ1Look();
            Console.WriteLine("- North");
            Console.WriteLine("- Southwest");
            Console.WriteLine("- East");


            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("look animal hospital") || action.ToLower().Contains("look hospital"))
                {
                    Text.LookAtHosp();
                }
                if (action.ToLower().Contains("look at hotel") || action.ToLower().Contains("look hotel"))
                {
                    Text.LookAtHotelFromBack();
                }
                if (action.ToLower().Contains("go west"))
                {
                    Text.OverDebris();
                    getout = true;
                    player.Room = 602;
                }
                if (action.ToLower().Contains("go southwest") || action.ToLower().Contains("go south"))
                {
                    Console.WriteLine("\nYou enter the alley to the southeast.");
                    getout = true;
                    player.Room = 12;
                }
                if (action.ToLower().Contains("go east"))
                {
                    Console.WriteLine("\nYou go east.");
                    getout = true;
                    player.Room = 9;
                }
                if (action.ToLower().Contains("go north") || action.ToLower().Contains("go to animal hospital") || action.ToLower().Contains("go hospital"))
                {
                    if (!warned)
                    {
                        Text.HospitalWarning();
                    }
                    else
                    {
                        Console.WriteLine("Well, okay.  You cross the street and enter the animal hospital.");
                        getout = true;
                        player.Room = 21;
                    }
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.MapZ1Look();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }





        //
        //
        //  Ruins of the old coffee shop, Z2 top center on map, player.Room == 9

        public static Player Outside2(Player player)
        {
            bool getout = false;
            bool warned = false;
            string action;

            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Text.MapZ2Look();
            Console.WriteLine("- East");
            Console.WriteLine("- West");
            Console.WriteLine("- South");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                
                if (action.ToLower().Contains("look at hotel") || action.ToLower().Contains("look hotel"))
                {
                    Text.LookAtHotelFromCafe();
                }
                else if (action.ToLower().Contains("look at bank") || action.ToLower().Contains("look bank"))
                {
                    Text.LookAtBankFromCafe();
                }
                else if (action.ToLower().Contains("look at mural") || action.ToLower().Contains("look mural"))
                {
                    Text.LookMural();
                }
                else if (action.ToLower().Contains("go east"))
                {
                    
                    player.Room = 10;
                    Console.WriteLine("You go to the east.");
                    getout = true;
                }
                else if (action.ToLower().Contains("go west"))
                {
                    
                    player.Room = 8;
                    Console.WriteLine("You head to the west.");
                    getout = true;
                }
                else if (action.ToLower().Contains("go south"))
                {
                    
                    player.Room = 13;
                    Console.WriteLine("You follow the road south.");
                    getout = true;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.MapZ2Look();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }


        //
        //
        // upper right corner of block, old playground, player.Room == 10, Z3
        public static Player Outside3(Player player)
        {
            
            bool getout = false;
            bool warned = false;
            string action;
            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Text.MapZ3Look();
            Console.WriteLine("- West.");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();
                Text.MapZ3Look();
                if (action.ToLower().Contains("look at merry") || action.ToLower().Contains("look merry"))
                {
                    Text.LookMerryRound();
                }
                else if (action.ToLower().Contains("look at teeter") || action.ToLower().Contains("look teeter"))
                {
                    Text.LookTeeterTotter();
                }
                else if (action.ToLower().Contains("look at swings") || action.ToLower().Contains("look swings"))
                {
                    // if player.Weapon contains chains, access Text.LookSwingsTwo 
                    // Add option when inventory figured out.
                    Text.LookSwings();
                }
                else if (action.ToLower().Contains("look loose swing"))
                {
                    // if player.Weapon contains chains, access Text.LookLooseTwo
                    // add option when inventory figured out.
                    Text.LookLooseSwing();
                }
                else if (action.ToLower().Contains("take chain"))
                {
                    // if player.Weapon contains chains, access Text.TakeChainTwo
                    // add option when inventory figured out.
                    Text.TakeChain();
                }
                else if (action.ToLower().Contains("look at mural") || action.ToLower().Contains("look mural"))
                {
                    Text.LookMural();
                }
                else if (action.ToLower().Contains("look bank") || action.ToLower().Contains("look at bank"))
                {
                    Text.LookBankWall();
                }
                else if (action.ToLower().Contains("play"))
                {
                    Text.Play();
                }
                else if (action.ToLower().Contains("go east"))
                {
                    if (!warned)
                    {
                        Text.CrossStreetWarning();
                        warned = true;
                    }
                    else
                    {
                        Text.CrossStreet();
                        player.Room = 603;
                        getout = true;
                    }
                }
                else if(action.ToLower().Contains("go west"))
                {
                    player.Room = 9;
                    getout = true;
                    Console.WriteLine("You go west, back to the cafe.");
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.MapZ3Look();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }

        // 
        //
        // Room removed for time constraints.  Merged with Z5.

        //public static Player Outside4(Player player)
        //{
        //    // back alley behind hotel
        //    bool getout = false;
        //    string action;

        //    while (!getout)
        //    { }
        //    return player;
        //}

            //
            //
            // Lower back alley behind hotel, Z5, center left of map, player.Room == 12
        public static Player Outside5(Player player)
        {
            // lower back alley behind hotel
            bool getout = false;
            bool warned = false;
            string action;

            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Text.MapZ5Look();
            Console.WriteLine("- North");
            Console.WriteLine("- South");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("search debris"))
                {
                    Text.SearchDebris();
                }
                else if (action.ToLower().Contains("go west"))
                {
                    if (!warned)
                    {
                        Console.WriteLine("\nSeriously, you don't want to climb over the debris.  Once you're outside Mange territory, it's basically a free for all, " +
                            "and you're not ready for that.");
                    }
                    else
                    {
                        Text.OverDebris();
                        getout = true;
                        player.Room = 602;
                    }
                }
                else if (action.ToLower().Contains("go north"))
                {
                    player.Room = 8;
                    getout = true;
                    Console.WriteLine("\nYou go north out of the alley.");
                }
                else if (action.ToLower().Contains("go south"))
                {
                    player.Room = 14;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.MapZ5Look();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }
        //
        //
        //  Area directly between hotel and bank, Z6, center of map, player.Room = 13;

        public static Player Outside6(Player player)
        {
            // between the hotel and the bank
            bool getout = false;
            string action;

            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Text.MapZ6Look();
            Console.WriteLine("- North");
            Console.WriteLine("- South");
            Console.WriteLine("- East");
            Console.WriteLine("- West");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("look bank") || action.ToLower().Contains("look at bank"))
                {
                    Text.LookBankFront();
                }
                else if (action.ToLower().Contains("look hotel") || action.ToLower().Contains("look at hotel"))
                {
                    Text.LookHotelFront();
                }
                else if (action.ToLower().Contains("go north"))
                {
                    Console.WriteLine("You follow the street up north");
                    getout = true;
                    player.Room = 9;
                }
                else if (action.ToLower().Contains("go south"))
                {
                    Console.WriteLine("You follow the street down south");
                    getout = true;
                    player.Room = 16;
                }
                else if (action.ToLower().Contains("go east")|| action.ToLower().Contains("enter bank"))
                {
                    Console.WriteLine("\nYou enter the bank.");
                    getout = true;
                    player.Room = 2;
                }
                else if (action.ToLower().Contains("go west") || action.ToLower().Contains("enter hotel"))
                {
                    Console.WriteLine("\nYou enter the hotel.");
                    getout = true;
                    player.Room = 5;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.MapZ6Look();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }





        //
        //
        //  Area above bakery, below hotel, left side of map, Z7, player.Room = 14;
        public static Player Outside7(Player player)
        {
            // Area above old bakery, left side of map
            bool getout = false;
            bool warned = false;
            string action;
            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            Text.MapZ7Look();
            Console.WriteLine("- Northwest");
            Console.WriteLine("- East");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("look at pizzaria") || action.ToLower().Contains("look pizzaria"))
                {
                    Text.LookPizzariaFromAlley();
                }
                else if(action.ToLower().Contains("look bakery")|| action.ToLower().Contains("look at bakery"))
                {
                    Text.LookBakeryFromAlley();
                }
                else if(action.ToLower().Contains("look at hotel") || action.ToLower().Contains("look hotel"))
                {
                    Text.LookHotelFromAlley();
                }
                else if(action.ToLower().Contains("look dumpster") || action.ToLower().Contains("look at dumpster"))
                {
                    Text.LookDumpster();
                }
                else if (action.ToLower().Contains("search dumpster"))
                {
                    if (!player.Inventory.Contains("flashlight"))
                    {
                        Text.SearchDumpster();
                        player.Cigarettes += 12;
                        player.Inventory.Add("flashlight");
                    }
                    else
                    {
                        Text.SearchDumpsterTwo();
                    }
                }
                else if(action.ToLower().Contains("take boards") || action.ToLower().Contains("remove boards"))
                {
                    Text.RemoveBoards();
                }
                else if(action.ToLower().Contains("go west"))
                {
                    if (!warned)
                    {
                        Console.WriteLine("\nSeriously, you don't want to climb over the debris.  Once you're outside Mange territory, it's basically a free for all, " +
                            "and you're not ready for that.");
                    }
                    else
                    {
                        Text.OverDebris();
                        getout = true;
                        player.Room = 602;
                    }
                }
                else if(action.ToLower().Contains("go northwest") || action.ToLower().Contains("go north"))
                {
                    Console.WriteLine("\nYou go northwest into the alley behind the hotel.");
                    getout = true;
                    player.Room = 12;
                }
                else if(action.ToLower().Contains("go east"))
                {
                    Console.WriteLine("\nYou go east.");
                    getout = true;
                    player.Room = 16;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.MapZ7Look();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }




        //Room Removed for time constraint reasons.
        //
        //
        //public static Player Outside8(Player player)
        //{
        //    // Alley behind old bakery, bottom left corner of map
        //    bool getout = false;
        //    string action;

        //    while (!getout)
        //    { }
        //    return player;
        //}


        

        //
        //
        //  bottom center of map, player.Room == 16, Z9
        public static Player Outside9(Player player)
        {
            Random rand = new Random();
            int num = rand.Next(1, 3);
            
            if ( num == 1)
            {
                Console.WriteLine("Time to battle!");               
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }
            // Large area east of bakery, bottom center of map
            bool getout = false;
            string action;
            Text.MapZ9Look();
            Console.WriteLine("- West");
            Console.WriteLine("- East");
            Console.WriteLine("- North");

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();


                if (action.ToLower().Contains("search rubble") || action.ToLower().Contains("search debris"))
                {
                    Text.SearchDebris();
                }
                else if(action.ToLower().Contains("look bakery") || action.ToLower().Contains("look at bakery"))
                {
                    Text.LookBakeryFront();
                }
                else if (action.ToLower().Contains("look pizzaria") || action.ToLower().Contains("look at pizzaria"))
                {
                    Text.LookPizzariaFront();
                }
                else if (action.ToLower().Contains("look blocks")|| action.ToLower().Contains("look square") || action.ToLower().Contains("look at blocks"))
                {
                    Text.LookBlocks();
                }
                else if (action.ToLower().Contains("search blocks"))
                {
                    Text.SearchBlocks();
                }
                else if (action.ToLower().Contains("go west")|| action.ToLower().Contains("enter bakery"))
                {
                    getout = true;
                    Console.WriteLine("You go west, back into the bakery");
                    player.Room = 1;
                }
                else if (action.ToLower().Contains("go east")|| action.ToLower().Contains("enter pizzaria"))
                {
                    getout = true;
                    Console.WriteLine("You go east, into the pizzaria.");
                    player.Room = 19;
                }
                else if(action.ToLower().Contains("go north"))
                {
                    getout = true;
                    Console.WriteLine("You go north, up the road");
                    player.Room = 13;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.MapZ9Look();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }

            }
            return player;
        }

        // Room Removed for time constraints.
        //
        //public static Player Outside10(Player player)
        //{
        //    // Large area further east of bakery, in front of pizzaria, bottom center of map
        //    bool getout = false;
        //    string action;

        //    while (!getout)
        //    { }
        //    return player;
        //}

        // Room Removed for time constraints.
        //
        //public static Player Outside11(Player player)
        //{
        //    // Alley just below the pizzaria, bottom right corner of map
        //    bool getout = false;
        //    string action;

        //    while (!getout)
        //    { }
        //    return player;
        //}

        public static Player Pizzaria(Player player)
        {
            bool getout = false;
            string action;
            Text.PizzariaLook();
            Console.WriteLine("- West");

            // in the pizzaria, eating food gets a +2 boost after battles, because the kitchen is available.

            Random rand = new Random();
            int num = rand.Next(1, 3);

            if (num == 1)
            {
                Console.WriteLine("Time to battle!");
                int random = _generator.Next(0, 5);
                Console.WriteLine($"A thug has appeared!");
                Battle(LoadingLists.Mobs[random].GangType, random, player);
            }
            else
            {
                Console.WriteLine("There seems to be no enemies this time.");
            }

            while (!getout)
            {
                Console.WriteLine("\n");
                action = Console.ReadLine();

                if (action.ToLower().Contains("use bathroom"))
                {
                    Text.UseBathroom();
                }
                else if (action.ToLower().Contains("bathroom"))
                {
                    Text.LookBathroom();
                }
                else if (action.ToLower().Contains("look kitchen") || action.ToLower().Contains("look at kitchen"))
                {
                    Text.LookKitchen();
                }
                else if (action.ToLower().Contains("cook") || action.ToLower().Contains("use kitchen"))
                {
                    Text.UseKitchen();
                }
                else if(action.ToLower().Contains("take coal")|| action.ToLower().Contains("get coal"))
                {
                    Text.TakeCoal();
                }
                else if (action.ToLower().Contains("look tables") || action.ToLower().Contains("look chairs"))
                {
                    Text.LookTables();
                }
                else if (action.ToLower().Contains("sit"))
                {
                    Text.SitDown();
                }
                else if (action.ToLower().Contains("coinhold"))
                {
                    Text.LookCoins();
                }
                else if (action.ToLower().Contains("take coins") || action.ToLower().Contains("get coins"))
                {
                    Text.TakeCoins();
                }
                else if (action.ToLower().Contains("look at jukebox")|| action.ToLower().Contains("look jukebox"))
                {
                    Text.LookJukebox();
                }
                else if (action.ToLower().Contains("use jukebox") || action.ToLower().Contains("play jukebox"))
                {
                    Text.UseJukebox();
                }
                else if (action.ToLower().Contains("go west"))
                {
                    Console.WriteLine("You exit the pizzaria.");
                    getout = true;
                    player.Room = 16;
                }
                else if (action.ToLower().Contains("go"))
                {
                    Console.WriteLine("\nYou can't go that way.");
                }
                // Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("look"))
                {
                    Text.PizzariaLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }
            return player;
        }


        // 
        //
        // This room has been eliminated from the game due to time constraints.  Here for reference.
        //public static Player PizzariaOffice(Player player)
        //{
        //    bool getout = false;
        //    string action;

        //    while (!getout)
        //    { }
        //    return player;
        //}

        public static Player AnimalControl1(Player player)
        {

            // Gang hangout
            bool getout = false;
            string action;

            // Possible variable for winning or losing the boss battle.  
            // You don't have to use it, it's just there to distinguish between losing or winning.
            // If there's a better way, feel free to replace this.
            bool winning = false;


            Text.BossEntrance();

            // Insert battle code here

            if (winning)
            {
                Text.BossWonText();
                player.Room = 144;
                getout = true;
            }
            else
            {
                Text.BossLoseText();
                player.Room = 604;
                getout = true;
            }





            // old code for reference

            ////Boss fight?
            //Random rand = new Random();
            //int num = rand.Next(1, 2);

            //if (num == 1)
            //{
            //    Console.WriteLine("Time to battle!");
            //    Console.WriteLine($"The boss {LoadingLists.Mobs[5].GangType} has appeared!");
            //    Battle(LoadingLists.Mobs[5].GangType, 5, player);
            //}
            //else
            //{
            //    Console.WriteLine("There seems to be no enemies this time.");
            //    Console.WriteLine(num);
            //}

            //while (!getout)
            //{


            //    //This code is marked out for now, as either one will die in the boss room, or win.  There is no option to leave.


            //    //
            //    //Console.WriteLine("\n");
            //    //action = Console.ReadLine();

            //    //if (action.ToLower().Contains(""))
            //    //{

            //    //}

            //    //else if (action.ToLower().Contains("go"))
            //    //{
            //    //    Console.WriteLine("\nYou can't go that way.");
            //    //}
            //    //// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
            //    //else if (action.ToLower().Contains("look"))
            //    //{
            //    //    Text.PizzariaLook();
            //    //}
            //    //else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
            //    //{
            //    //    Text.LookInventory(player);
            //    //}
            //    //else if (action.ToLower().Contains("help"))
            //    //{
            //    //    Text.Help();
            //    //}
            //    //else
            //    //{
            //    //    Console.WriteLine("\nInput not understood.");
            //    //}
            //}
            return player;
        }

        // Room Removed for time constraints.
        //
        //public static Player AnimalControl2(Player player)
        //{
        //    // Big Boss Room
        //    bool getout = false;
        //    string action;

        //    while (!getout)
        //    { }
        //    return player;
        //}
        public static void Battle(string Mob, int random, Player player)
        {
            Thug newthug = LoadingLists.Mobs[random];
            Thug newthug6 = LoadingLists.Mobs[5];
            double potionUse = 0;

            if (Mob == newthug.GangType)
            {
                while (newthug.HP > 0)
                {
                    //Console.WriteLine($"You attack for {player.Weapon.Damage} damage!");
                    Console.WriteLine($"You attack for {5} damage!");
                    //newthug.HP -= player.Weapon.Damage;
                    newthug.HP -= 5;
                    Console.WriteLine($"{newthug.GangType}'s health is at {newthug.HP}.");

                    if (newthug.HP > 0)
                    {
                        Console.WriteLine($"{newthug.GangType} attacks you for {newthug.Weapon.Damage} damage!");
                        player.HP -= newthug.Weapon.Damage;
                        Console.WriteLine($"Your health is at {player.HP}.");

                        if (player.HP <= 10 & player.HP > 0)
                        {
                            Console.WriteLine("Do you wish to use a potion?");
                            Console.WriteLine("Yes or no? ");
                            string potionChoice = Console.ReadLine();

                            if (potionChoice == "yes" & potionUse == 0)
                            {
                                Potion newpotion = LoadingLists.potionList[0];
                                player.HP += newpotion.Boost;
                                Console.WriteLine($"Your health is now at {player.HP} after using the potion.");
                                potionUse += 1;
                            }
                            else if (potionChoice == "yes" & potionUse == 1)
                            {
                                Potion newpotion = LoadingLists.potionList[1];
                                player.HP += newpotion.Boost;
                                Console.WriteLine($"Your health is now at {player.HP} after using the potion.");
                                potionUse += 1;
                            }
                            else if (potionChoice == "yes" & potionUse > 1)
                            {
                                Console.WriteLine("Sorry you are out of potions!");
                            }
                            else if (potionChoice == "no")
                            {
                                Console.WriteLine("Ok, good luck with not using a potion!");
                            }
                            else
                            {
                                Console.WriteLine("error on potion");
                            }
                        }
                        else if (player.HP <= 0)
                        {
                            newthug.HP = 0;
                            player.HP = 25;
                            Console.WriteLine("The enemy is victorious and leaves you unconscious while running away laughing gleefully.");
                            Console.WriteLine("After a while, you slowly regain consciousness with your pride wounded but you continue on.");
                        }
                    }
                    else
                    {
                        player.HP = 25;
                        Console.WriteLine("Thug is dead!");
                    }
                    Console.ReadLine();
                }

            }
            else if (Mob == newthug6.GangType)
            {
                while (newthug6.HP > 0)
                {
                    //Console.WriteLine($"You attack for {player.Weapon.Damage} damage!");
                    Console.WriteLine($"You attack for {5} damage!");
                    //newthug.HP -= player.Weapon.Damage;
                    newthug.HP -= 5;
                    Console.WriteLine($"{newthug6.GangType}'s health is at {newthug6.HP}.");

                    if (newthug.HP > 0)
                    {
                        Console.WriteLine($"{newthug6.GangType} attacks you for {newthug6.Weapon.Damage} damage!");
                        player.HP -= newthug6.Weapon.Damage;
                        Console.WriteLine($"Your health is at {player.HP}.");

                        if (player.HP <= 10 & player.HP > 0)
                        {
                            Console.WriteLine("Do you wish to use a potion?");
                            Console.WriteLine("Yes or no? ");
                            string potionChoice = Console.ReadLine();

                            if (potionChoice == "yes" & potionUse == 0)
                            {
                                Potion newpotion = LoadingLists.potionList[0];
                                player.HP += newpotion.Boost;
                                Console.WriteLine($"Your health is now at {player.HP} after using the potion.");
                                potionUse += 1;
                            }
                            else if (potionChoice == "yes" & potionUse == 1)
                            {
                                Potion newpotion = LoadingLists.potionList[1];
                                player.HP += newpotion.Boost;
                                Console.WriteLine($"Your health is now at {player.HP} after using the potion.");
                                potionUse += 1;
                            }
                            else if (potionChoice == "yes" & potionUse > 1)
                            {
                                Console.WriteLine("Sorry you are out of potions!");
                            }
                            else if (potionChoice == "no")
                            {
                                Console.WriteLine("Ok, good luck with not using a potion!");
                            }
                            else
                            {
                                Console.WriteLine("error on potion");
                            }
                        }
                        else if (player.HP <= 0)
                        {
                            newthug6.HP = 0;
                            player.HP = 25;
                            Console.WriteLine("The boss is victorious and destroys your body");
                        }
                    }
                    else
                    {

                        Console.WriteLine("The boss is defeated!");
                    }
                    Console.ReadLine();
                }


            }
        }

        private static Random _generator = new Random();
    }
}
