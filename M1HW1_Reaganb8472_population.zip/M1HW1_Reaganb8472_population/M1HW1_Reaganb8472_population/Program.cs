﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Bethany Reagan
* CSC 253
* August 29, 2019
* Program to predict approximate size of a population
*/

namespace M1HW1_Reaganb8472_population
{
    class Program
    {
        static void Main(string[] args)
        {
            // number of organisms in population
            int numOrganisms = -1;
            //Average daily increase of organisms
            double averageDI = 0.0;
            // number of days organisms reproduce
            int numDays = 0;
			// size of population in the end
			int numEnd = 0;
            // program is engaged or not.
            bool program = true;

            Console.WriteLine("Welcome to the population program.  You must determine the growth of a given population based on a percentage " +
                "and a base starting population.  Happy Science!");

            do
            {
                Console.WriteLine("\nPlease choose an option: ");
                Console.WriteLine("1. Enter the necessary variables.");
                Console.WriteLine("2. Determine the growth of the population.");
                Console.WriteLine("3. Exit.");
                Console.Write("Option#: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write($"\nAlright, how many organisms are in the population?  Enter an integer:  ");
                        while (!int.TryParse(Console.ReadLine(), out numOrganisms))
                        {
                            Console.WriteLine("That is not an integer.");
                            Console.Write($"Alright, how many organisms are in the population?  Enter an integer:  ");
                        }
						Console.Write($"What is the average daily increase in population?  Enter a percentage:  ");
                        while (!double.TryParse(Console.ReadLine(), out averageDI))
                        {
                            Console.WriteLine("That isn't right.");
                            Console.Write($"What is the average daily increase in population?  Enter a percentage:  ");
                        }
						Console.Write($"And how many days will they be reproducing?  Enter an integer:  ");
                        while (!int.TryParse(Console.ReadLine(), out numDays))
                        {
                            Console.WriteLine("That is not an integer.");
                            Console.Write($"And how many days will they be reproducing?  Enter an integer:  ");
                        }
						Console.Write("Data entry complete!\n");
                        break;
                    case "2":
                        if (numOrganisms == -1)
						{
                            Console.WriteLine("You haven't entered in the necessary variables yet.\n");
							break;
						}
                        else
                        {
							double numOrganisms2 = numOrganisms;
							for (int i =0; i < numDays; i++){
                                numOrganisms2 = numOrganisms2 * (averageDI+1);
							}

                            numEnd = (int)numOrganisms2;

							Console.WriteLine($"Over a period of {numDays} days and an average daily increase of {averageDI} percent, "+
							$"The starting population of " + string.Format("{0:n0}",numOrganisms) + $" will become {numEnd}.");
                        }
                        break;
                    case "3":
                        Console.WriteLine("Thanks for coming by the lab!  Have a great day!\n");
                        program = false;
                        break;
                    default:
                        Console.WriteLine("I'm sorry, I didn't understand that.  Say again?\n");
                        break;
                }



            } while (program == true);
        }
    }
}
