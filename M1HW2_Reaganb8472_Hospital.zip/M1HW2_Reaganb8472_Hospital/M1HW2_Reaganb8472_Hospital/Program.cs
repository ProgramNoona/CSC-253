﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Bethany Reagan
* CSC 253
* September 2, 2019
* Program to calculate hospital fees
*/

namespace M1HW1_Reaganb8472_population
{
    class Program
    {
        static void Main(string[] args)
        {
            // base charge for a hospital
            decimal baseCharge = 350.0m;
            // number of days in the hospital
            int numDays = -1;
            // medication charges
            decimal medCharge = 0.0m;
            // surgical charges
            decimal surgCharge = 0.0m;
            // lab fees;
            decimal labFee = 0.0m;
            // physical rehab charges;
            decimal rehabCharge = 0.0m;
            // total charges just for staying;
            decimal totBaseCharge = 0.0m;
            // total treatment charges
            decimal totTreatCharge = 0.0m;
            // total charges
            decimal totAllCharge = 0.0m;
            // program is engaged or not.
            bool program = true;

            Console.WriteLine("Welcome to the hospital pay program, where we determine how much you owe us!  Oh happy day!  " +
            "Well, not for you.");

            do
            {
                Console.WriteLine("\nPlease choose an option: ");
                Console.WriteLine("1. Enter your information.");
                Console.WriteLine("2. Calculate the base charges for your stay.");
                Console.WriteLine("3. Calculate the charges for your treatment.");
                Console.WriteLine("4. Calculate the total charges.");
                Console.WriteLine("5. Exit.");
                Console.Write("Option#: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write($"Alright, how many days did you stay in the hospital?  Enter an integer:  ");
                        while (!int.TryParse(Console.ReadLine(), out numDays))
                        {
                            Console.WriteLine("That is not an integer.");
                            Console.Write($"Alright, how many days did you stay in the hospital?  Enter an integer:  ");
                        }
                        Console.Write($"What are your medication charges?  ");
                        while (!decimal.TryParse(Console.ReadLine(), out medCharge))
                        {
                            Console.WriteLine("That isn't right.");
                            Console.Write($"What are your medication charges?  ");
                        }
                        Console.Write($"What are your surgical charges?  ");
                        while (!decimal.TryParse(Console.ReadLine(), out surgCharge))
                        {
                            Console.WriteLine("That is not a number.");
                            Console.Write($"What are your surgical charges?  ");
                        }
                        Console.Write($"What are your lab fees?  ");
                        while (!decimal.TryParse(Console.ReadLine(), out labFee))
                        {
                            Console.WriteLine("That is not a number.");
                            Console.Write($"What are your lab fees?  ");
                        }
                        Console.Write($"What are your physical rehabilitation charges?  ");
                        while (!decimal.TryParse(Console.ReadLine(), out rehabCharge))
                        {
                            Console.WriteLine("That is not a number.");
                            Console.Write($"What are your physical rehabilitation charges?  ");
                        }
                        Console.WriteLine("Data entry complete!");
                        break;
                    case "2":
                        if (numDays == -1)
                        {
                            Console.WriteLine("You haven't entered in the necessary variables yet.\n");
                            break;
                        }
                        else if (numDays == 0)
                        {
                            Console.WriteLine("You have stayed zero days?  Looks like you don't owe us anything at all.");
                            break;
                        }
                        else
                        {
                            totBaseCharge = baseCharge * numDays;
                            Console.WriteLine($"For staying {numDays} days, you owe a total of " + string.Format("{0:c}", totBaseCharge) +
                                ".");
                        }
                        break;
                    case "3":
                        if (numDays == -1)
                        {
                            Console.WriteLine("You haven't entered in the necessary variables yet.\n");
                            break;
                        }
                        else if (numDays == 0)
                        {
                            Console.WriteLine("How do you have any treatment charges if you stayed zero days?");
                            break;
                        }
                        else
                        {
                            totTreatCharge = medCharge + surgCharge + labFee + rehabCharge;
                            Console.WriteLine($"The total costs of your treatment come to " +
                                string.Format("{0:c}", totTreatCharge) + ".");
                        }
                        break;
                    case "4":
                        if (numDays == -1)
                        {
                            Console.WriteLine("You haven't entered in the necessary variables yet.\n");
                            break;
                        }
                        else if (numDays == 0)
                        {
                            Console.WriteLine("You stayed zero days.  You have no charges.");
                            break;
                        }
                        else
                        {
                            totAllCharge = baseCharge * numDays + medCharge + surgCharge + labFee + rehabCharge;
                            Console.WriteLine($"For staying {numDays} days and receiving treatment, your hospital bill comes to " +
                                string.Format("{0:c}", totAllCharge) + ".");
                        }
                        break;
                    case "5":
                        Console.WriteLine("How will you be paying us?\n");
                        program = false;
                        break;
                    default:
                        Console.WriteLine("I'm sorry, I didn't understand that.  Say again?\n");
                        break;
                }



            } while (program == true);
        }
    }
}
