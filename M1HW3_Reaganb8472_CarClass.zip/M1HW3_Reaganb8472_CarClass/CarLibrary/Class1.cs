﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public class Car
    {
        private string _year;
        private string _make;
        private int _speed;

        public Car()
        {
            Year = null;
            Make = null;
            Speed = 0;

        }

        public Car (string year, string make)
        {
            Year = year;
            Make = make;
            Speed = 0;
        }

        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }

        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        public static Car InputCar()
        {
            Car output = new Car();
            Console.Write("What is the year of the car?  ");
            output.Year = Console.ReadLine();
            Console.Write("What is the make of the car?  ");
            output.Make = Console.ReadLine();
            output.Speed = 0;

            return output;
        }
    }
}
