﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    class Work
    {
        public static Car InputCar()
        {
            Car output = new Car();
            Console.Write("What is the year of the car?  ");
            output.Year = Console.ReadLine();
            Console.Write("What is the make of the car?  ");
            output.Make = Console.ReadLine();
            output.Speed = 0;

            return output;
        }
    }
}
