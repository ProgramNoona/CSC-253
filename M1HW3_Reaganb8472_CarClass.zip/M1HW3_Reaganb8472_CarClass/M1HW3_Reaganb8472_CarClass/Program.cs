﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Bethany Reagan
* CSC 253
* September 3, 2019
* Program to create a car class
*/

namespace M1HW3_Reaganb8472_CarClass
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;
            CarLibrary.Car car = new CarLibrary.Car();
            do
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Input car.");
                Console.WriteLine("2. View car.");
                Console.WriteLine("3. Accelerate.");
                Console.WriteLine("4. Brake.");
                Console.WriteLine("5. Exit");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.WriteLine("\n");
                        car = CarLibrary.Car.InputCar();
                        break;
                    case "2":
                        if (car.Make == null)
                        {
                            Console.WriteLine("\nYou haven't inputted a car yet.\n");
                        }
                        else
                        {
                            Console.WriteLine($"\nThe {car.Make} is a {car.Year}, and it is going {car.Speed} miles per hour.");
                        }
                        break;
                    case "3":
                        Console.WriteLine("\nSpeeding up!");
                        car.Speed += 5;
                        Console.WriteLine($"The car is travelling {car.Speed} miles per hour.");
                        break;
                    case "4":
                        if (car.Speed == 0)
                        {
                            Console.WriteLine("The car isn't moving.");
                        }
                        else
                        {
                            Console.WriteLine("Slowing down...");
                            car.Speed -= 5;
                            if (car.Speed == 0)
                            {
                                Console.WriteLine("The car has come to a stop.");
                            }
                            else
                            {
                                Console.WriteLine($"The car is travelling {car.Speed} miles per hour.");
                            }
                        }
                        break;
                    case "5":
                        program = false;
                        break;
                }
            } while (program == true);
        }
    }
}
