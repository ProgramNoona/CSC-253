﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M1HW4_Reaganb8472_RetailItem
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;
            RetailLibrary.RetailItem emp = new RetailLibrary.RetailItem();
            List<RetailLibrary.RetailItem> items = new List<RetailLibrary.RetailItem>();

            do
            {
                Console.WriteLine("Select a choice below --- ");
                Console.WriteLine("1. Input an Item.");
                Console.WriteLine("2. View all items.");
                Console.WriteLine("3. Exit");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        emp = RetailLibrary.RetailItem.InputItem();
                        items.Add(emp);
                        break;
                    case "2":
                        Console.WriteLine("Here are the items -- ");
                        foreach (RetailLibrary.RetailItem emplo in items)
                        {
                            Console.WriteLine($"Item: {emp.Description} \n# in Stock: {emp.Units} \nRetail Price: {emp.Price}\n\n");
                        }
                        Console.WriteLine("\n");
                        break;
                    case "3":
                        program = false;
                        break;
                }
            } while (program == true);
        }
    }
}
