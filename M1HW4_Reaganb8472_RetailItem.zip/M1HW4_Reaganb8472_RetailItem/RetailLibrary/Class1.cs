﻿using System;

namespace RetailLibrary
{
    public class RetailItem
    {
        private string _description;
        private int _units;
        private decimal _price;

        public RetailItem()
        {
            Description = null;
            Units = 0;
            Price = 0.0m;
        }

        public RetailItem(string description, int units, decimal price)
        {
            Description = description;
            Units = units;
            Price = price;
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        
        public int Units
        {
            get { return _units; }
            set { _units = value; }
        }

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public static RetailItem InputItem()
        {
            int unitsDoof;
            decimal priceDoof;

            RetailLibrary.RetailItem output = new RetailLibrary.RetailItem();
            Console.Write("What item are you selling?  ");
            output.Description = Console.ReadLine();
            Console.Write("How many are in stock?  ");
            while (!int.TryParse(Console.ReadLine(), out unitsDoof))
            {
                Console.WriteLine("\nThat isn't right.");
                Console.Write("\nHow many of this item are in stock ? ");
            }
            Console.Write("What is the price of the item?  ");
            while (!decimal.TryParse(Console.ReadLine(), out priceDoof))
            {
                Console.WriteLine("\nThat isn't right.");
                Console.Write("\nWhat is the price of the item?  ");
            }
            output.Units = unitsDoof;
            output.Price = priceDoof;

            return output;
        }

    }
}
