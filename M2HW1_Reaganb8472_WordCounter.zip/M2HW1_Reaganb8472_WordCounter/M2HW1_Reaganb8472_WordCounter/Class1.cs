﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2HW1_Reaganb8472_WordCounter
{
    public class Display
    {
        public static void Counter(string stringTest)
        {
            int count = 0;
            char doof = 'a';
            int characters = 0;

            for (int index = 0; index < stringTest.Length; index++)
            {
                if (char.IsLetter(stringTest, index) == true && doof == 'a')
                {
                    count += 1;
                    doof = 'b';
                    characters += 1;
                }
                else if (char.IsWhiteSpace(stringTest, index) == true)
                {
                    doof = 'a';
                }
                else
                {
                    characters += 1;
                }
            }

            Console.WriteLine($"Your string, \"{stringTest}\", is {characters} characters long.  " +
                $"It has {count} words in it.");
        }
    }
}
