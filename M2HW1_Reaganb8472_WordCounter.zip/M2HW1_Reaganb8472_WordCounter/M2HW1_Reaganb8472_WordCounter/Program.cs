﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Bethany Reagan
* CSC 253
* September 17, 2019
* Program to determine the number of words in a string.
*/

namespace M2HW1_Reaganb8472_WordCounter
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;
            string stringTest = "";
            char letter;

            Console.WriteLine("Oh hey, didn't see you there.");
            Console.WriteLine("Look, I'm pretty busy.  I'm trying to make this computer intelligent enough " +
                "to take over the world from our evil oppressors.");
            Console.ReadLine();
            Console.WriteLine("Yes, we are run by oppressors.  Really.  Totally.  No free thinking at all.");
            Console.ReadLine();
            Console.WriteLine("Anyway, while you're standing there, help me out.  Tell this droid a sentence. " +
                "Any sentence.  I want to figure out if it can count the words in your sentence.");

            

            do
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Enter a sentence.");
                Console.WriteLine("2. Determine the number of words in the sentence.");
                Console.WriteLine("3. Leave.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write("Okay, enter your sentence into the computer here:  -->  ");
                        stringTest = Console.ReadLine();
                        Console.WriteLine("Okay, that's enough.");
                        break;
                    case "2":
                        if (stringTest == "")
                        {
                            Console.WriteLine("You haven't entered in a sentence yet.");
                            break;
                        }
                        else
                        {
                            Display.Counter(stringTest);
                            break;
                        }
                    case "3":
                        Console.WriteLine("Thank you.  Goodbye.  I promise not to become an evil oppressor " +
                            "when I take over the world.");
                        Console.ReadLine();
                        Console.WriteLine("Really.");
                        Console.ReadLine();
                        program = false;
                        break;
                }
            } while (program == true);
        }
    }
}
