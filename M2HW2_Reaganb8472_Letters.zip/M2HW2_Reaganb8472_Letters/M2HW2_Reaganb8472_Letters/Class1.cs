﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2HW2_Reaganb8472_Letters
{
    class Describe
    {
        public static void Letters(string stringTest, List<int> lettersInWord)
        {
            int countWords = 0;
            char doof = 'a';
            int characters = 0;
            int charperword = 0;
            int wordSum = 0;
            double wordAverage = 0;

            for (int index = 0; index < stringTest.Length; index++)
            {
                // if the item is the first letter of a word
                if (char.IsLetter(stringTest, index) == true && doof == 'a')
                {
                    countWords += 1;
                    doof = 'b';
                    characters += 1;
                    charperword += 1;
                }
                // if the item is a letter other than the first
                else if (char.IsLetter(stringTest, index) == true && doof == 'b')
                {
                    characters += 1;
                    charperword += 1;
                }
                // if the item is whitespace
                else if (char.IsWhiteSpace(stringTest, index) == true)
                {
                    doof = 'a';
                    lettersInWord.Add(charperword);
                    wordSum += charperword;
                    charperword = 0;
                }
                else //If an item is neither a letter or whitespace, it is a symbol.
                {
                    characters += 1;
                    doof = 'a';
                    if (charperword != 0)
                    {
                        lettersInWord.Add(charperword);
                        wordSum += charperword;
                        charperword = 0;
                    }

                }
            }

            //Alright, now figure out the average.
            wordAverage = wordSum / lettersInWord.Count();

            Console.WriteLine($"Your string, \"{stringTest}\", is {characters} characters long.  " +
                $"{wordSum} of those characters are letters.  " +
                $"The average number of letters per word is {wordAverage}.  " +
                $"The string has {countWords} words in it.");
        }
    }
}
