﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2HW2_Reaganb8472_Letters
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;
            string stringTest = "";
            char letter;
            List<int> lettersInWord = new List<int>();

            Console.WriteLine("Whoa!  Don't sneak up on me like that.");
            Console.WriteLine("Yeah, I'm still working on this droid.  Glad you're back, actually. " +
                "I need a test subject -- I mean, I need you to help test the AI again.");
            Console.ReadLine();
            Console.WriteLine("No no, the droid is fine.  It won't electrocute you when you touch it.");
            Console.ReadLine();
            Console.WriteLine("...Most likely.");
            Console.ReadLine();
            Console.WriteLine("Anyway, while you're standing there, help me out.  Tell this droid a sentence. " +
                "Any sentence.  I want to figure out if it can figure out the average number of letters in your sentence.");



            do
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Enter a sentence.");
                Console.WriteLine("2. Calculate sentence statistics.");
                Console.WriteLine("3. Leave.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write("Okay, enter your sentence into the computer here:  -->  ");
                        stringTest = Console.ReadLine();
                        Console.WriteLine("\nOkay, that's enough.");
                        break;
                    case "2":
                        if (stringTest == "")
                        {
                            Console.WriteLine("You haven't entered in a sentence yet.");
                            break;
                        }
                        else
                        {
                            Describe.Letters(stringTest, lettersInWord);
                            break;
                        }
                    case "3":
                        Console.WriteLine("Thank you.  Goodbye.");
                        Console.ReadLine();
                        Console.WriteLine("Seriously, I've got to get to work.  Go away.");
                        Console.ReadLine();
                        program = false;
                        break;
                }
            } while (program == true);
        }
    }
}
