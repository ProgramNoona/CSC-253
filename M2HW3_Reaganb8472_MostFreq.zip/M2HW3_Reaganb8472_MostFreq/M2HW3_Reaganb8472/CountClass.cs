﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2HW3_Reaganb8472
{
    class CountClass
    {

        public static void CountLetters(string stringTest)
        {
            int[] freq = new int[26];

            stringTest = stringTest.ToLower();

            for (int i = 0; i < stringTest.Length; i++)
            {

                if (stringTest[i] == 'a')
                {

                    freq[0]++;
                }
                else if (stringTest[i] == 'b')
                {
                    freq[1]++;
                }
                else if (stringTest[i] == 'c')
                {

                    freq[2]++;
                }
                else if (stringTest[i] == 'd')
                    {

                    freq[3]++;
                }
                else if(stringTest[i] == 'e')
                    {

                    freq[4]++;
                }
                else if(stringTest[i] == 'f')
                    {

                    freq[5]++;
                }
                else if(stringTest[i] == 'g')
                    {

                    freq[6]++;
                }
                else if(stringTest[i] == 'h')
                    {

                    freq[7]++;
                }
                else if(stringTest[i] == 'i')
                    {

                    freq[8]++;
                }
                else if(stringTest[i] == 'j')
                    {

                    freq[9]++;
                }
                else if(stringTest[i] == 'k')
                    {

                    freq[10]++;
                }
                else if(stringTest[i] == 'l')
                    {

                    freq[11]++;
                }
                else if(stringTest[i] == 'm')
                    {

                    freq[12]++;
                }
                else if(stringTest[i] == 'n')
                    {

                    freq[13]++;
                }
                else if(stringTest[i] == 'o')
                    {

                    freq[14]++;
                }
                else if(stringTest[i] == 'p')
                    {

                    freq[15]++;
                }
                else if(stringTest[i] == 'q')
                    {

                    freq[16]++;
                }
                else if(stringTest[i] == 'r')
                    {

                    freq[17]++;
                }
                else if(stringTest[i] == 's')
                    {

                    freq[18]++;
                }
                else if(stringTest[i] == 't')
                    {

                    freq[19]++;
                }
                else if(stringTest[i] == 'u')
                    {

                    freq[20]++;
                }
                else if(stringTest[i] == 'v')
                    {

                    freq[21]++;
                }
                else if(stringTest[i] == 'w')
                    {

                    freq[22]++;
                }
                else if(stringTest[i] == 'x')
                {

                    freq[23]++;
                }
                else if(stringTest[i] == 'y')
                {

                    freq[24]++;
                }
                else if(stringTest[i] == 'z')
                {

                    freq[25]++;
                }
                else
                {

                }
            }


            
            if (freq[0] > 0)
            {
                Console.WriteLine($"Letter: A  Frequency: {freq[0]}");
            }
            if (freq[1] > 0)
            {
                Console.WriteLine($"Letter: B  Frequency: {freq[1]}");
            }
            if (freq[2] > 0)
            {
                Console.WriteLine($"Letter: C  Frequency: {freq[2]}");
            }
            if (freq[3] > 0)
            {
                Console.WriteLine($"Letter: D  Frequency: {freq[3]}");
            }
            if (freq[4] > 0)
            {
                Console.WriteLine($"Letter: E  Frequency: {freq[4]}");
            }
            if (freq[5] > 0)
            {
                Console.WriteLine($"Letter: F  Frequency: {freq[5]}");
            }
            if (freq[6] > 0)
            {
                Console.WriteLine($"Letter: G  Frequency: {freq[6]}");
            }
            if (freq[7] > 0)
            {
                Console.WriteLine($"Letter: H  Frequency: {freq[7]}");
            }
            if (freq[8] > 0)
            {
                Console.WriteLine($"Letter: I  Frequency: {freq[8]}");
            }
            if (freq[9] > 0)
            {
                Console.WriteLine($"Letter: J  Frequency: {freq[9]}");
            }
            if (freq[10] > 0)
            {
                Console.WriteLine($"Letter: K  Frequency: {freq[10]}");
            }
            if (freq[11] > 0)
            {
                Console.WriteLine($"Letter: L  Frequency: {freq[11]}");
            }
            if (freq[12] > 0)
            {
                Console.WriteLine($"Letter: M  Frequency: {freq[12]}");
            }
            if (freq[13] > 0)
            {
                Console.WriteLine($"Letter: N  Frequency: {freq[13]}");
            }
            if (freq[14] > 0)
            {
                Console.WriteLine($"Letter: O  Frequency: {freq[14]}");
            }
            if (freq[15] > 0)
            {
                Console.WriteLine($"Letter: P  Frequency: {freq[15]}");
            }
            if (freq[16] > 0)
            {
                Console.WriteLine($"Letter: Q  Frequency: {freq[16]}");
            }
            if (freq[17] > 0)
            {
                Console.WriteLine($"Letter: R  Frequency: {freq[17]}");
            }
            if (freq[18] > 0)
            {
                Console.WriteLine($"Letter: S  Frequency: {freq[18]}");
            }
            if (freq[19] > 0)
            {
                Console.WriteLine($"Letter: T  Frequency: {freq[19]}");
            }
            if (freq[20] > 0)
            {
                Console.WriteLine($"Letter: U  Frequency: {freq[20]}");
            }
            if (freq[21] > 0)
            {
                Console.WriteLine($"Letter: V  Frequency: {freq[21]}");
            }
            if (freq[22] > 0)
            {
                Console.WriteLine($"Letter: W  Frequency: {freq[22]}");
            }
            if (freq[23] > 0)
            {
                Console.WriteLine($"Letter: X  Frequency: {freq[23]}");
            }
            if (freq[24] > 0)
            {
                Console.WriteLine($"Letter: Y  Frequency: {freq[24]}");
            }
            if (freq[25] > 0)
            {
                Console.WriteLine($"Letter: Z  Frequency: {freq[25]}");
            }



        }
    }
}
