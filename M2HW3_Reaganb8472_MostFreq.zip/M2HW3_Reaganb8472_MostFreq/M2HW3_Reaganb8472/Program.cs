﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Bethany Reagan
* CSC 253
* September 24, 2019
* Program to count letters.
*/

namespace M2HW3_Reaganb8472
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Okay, so here's the thing.");
            Console.WriteLine("I am very confident that there is a better way to count the letters in a string.");
            Console.WriteLine("However, I am so super behind in this, and have not had the time to properly study. " +
                "I am also super scared of falling behind in math.  I signed up for precalculus this semester, " +
                "not realizing that it is related to the bane of my existence, geometry.");
            Console.ReadLine();
            Console.WriteLine("But enough complaining.  My point is, I'm doing this the overcomplicated way because I can't " +
                "figure out how to do it the proper way.  Forgive me, Sensei.");

            bool program = true;
            string stringTest = "";

            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Enter a sentence.");
                Console.WriteLine("2. Figure out which letter happens the most often.");
                Console.WriteLine("3. Leave.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write("Okay, enter your sentence into the computer here:  -->  ");
                        stringTest = Console.ReadLine();
                        Console.WriteLine("\nOkay, that's enough.");
                        break;
                    case "2":
                        if (stringTest == "")
                        {
                            Console.WriteLine("\nYou have not entered in a sentence.");
                            break;
                        }
                        else
                        {
                            CountClass.CountLetters(stringTest);
                            break;
                        }
                    case "3":
                        Console.WriteLine("Thank you.  Goodbye.");
                        Console.ReadLine();
                        program = false;
                        break;
                }
            }
        }
    }
}
