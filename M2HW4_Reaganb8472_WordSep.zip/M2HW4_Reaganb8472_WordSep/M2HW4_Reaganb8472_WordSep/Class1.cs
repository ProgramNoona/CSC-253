﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2HW4_Reaganb8472_WordSep
{
    public class Processor
    {
        public static void Separate(string sample)
        {
            for (int i =0; i < sample.Length; i++)
            {
                if (char.IsUpper(sample[i]) == true && i != 0)
                {
                    Console.Write(" ");
                    Console.Write(sample[i]);
                }
                else
                {
                    Console.Write(sample[i]);
                }
      
            }
        }
    }
}
