﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Bethany Reagan
* CSC 253
* September 24, 2019
* Program to print spaces in a string.
*/

namespace M2HW4_Reaganb8472_WordSep
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Oh hey, you're back.");
            Console.ReadLine();
            Console.WriteLine("Yeah, I'm not doing that world conquering thing anymore.  It turns out if you take over " +
                "the world, people expect you to lead it.  Way too much work.");
            Console.WriteLine("I'm still working on the AI thing though.  Seems a shame to let it go to waste.  " +
                "Anyway, look at what I'm doing. I'm taking these strings and separating them into proper sentences.");
            Console.WriteLine("I have no idea how it would be useful, but I'm bored.");

            bool program = true;
            string sample = "ThisIsASentenceToBeRead.";
            string finished = "";

            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. View sample string.");
                Console.WriteLine("2. Separate out the string.");
                Console.WriteLine("3. Leave.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write($"The string is \"{sample}\"");
                        break;
                    case "2":
                        Processor.Separate(sample);
                        break;
                    case "3":
                        Console.WriteLine("Wasn't that cute?");
                        Console.ReadLine();
                        program = false;
                        break;
                }
            }
        }
    }
}
