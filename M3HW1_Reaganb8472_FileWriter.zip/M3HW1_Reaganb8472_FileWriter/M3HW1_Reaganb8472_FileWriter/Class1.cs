﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* Bethany Reagan
* CSC 253
* September 26, 2019
* Program to write numbers to a file
*/

namespace M3HW1_Reaganb8472_FileWriter
{
    public class Save
    {
        public static void SaveNumbers(int howMany)
        {
            var random = new Random();

            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("random_numbers.txt");

                Console.WriteLine("\n");

                for (int i = 0; i < howMany; i++)
                {
                    int randNum = random.Next(1, 100);
                    Console.WriteLine($"Number {i}: {randNum}");
                    outputFile.WriteLine(randNum);
                }

                outputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
