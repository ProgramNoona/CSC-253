﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M3HW1_Reaganb8472_FileWriter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Random numbers!  Random numbers!  Get 'em while they're hot!");
            Console.WriteLine("Well, hello there, little lady.  How many random numbers would you like?");

            bool program = true;
            int howMany = 0;

            while (program)
            {

                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Tell the nice man how many numbers you want.");
                Console.WriteLine("2. See and save your numbers to file.");
                Console.WriteLine("3. Pay and leave.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

            

                switch (input)
                {
                    case "1":
                        Console.Write("Okay, how many do you want?  ");
                        while (!int.TryParse(Console.ReadLine(), out howMany))
                        {
                            Console.WriteLine("That is not an integer.");
                            Console.Write($"How many numbers do you want?  Enter an integer:  ");
                        }
                        Console.WriteLine("\nAlright, I'm cooking up your numbers right now.");
                        break;
                    case "2":
                        if (howMany == 0)
                        {
                            Console.WriteLine("You haven't told me how many you want.");
                            break;
                        }
                        else
                        { 
                            Save.SaveNumbers(howMany);
                            break;
                        }
                    case "3":
                        Console.WriteLine("Have a great day, Sweetie.");
                        Console.ReadLine();
                        program = false;
                        break;
                    default:
                        Console.WriteLine("\nI'm sorry, little girl, you'll have to speak up over this crowd.");
                        break;
                }
            }
        }
    }
}
