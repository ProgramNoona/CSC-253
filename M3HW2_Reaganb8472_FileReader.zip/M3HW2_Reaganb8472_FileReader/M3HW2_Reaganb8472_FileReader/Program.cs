﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Bethany Reagan
* CSC 253
* September 26, 2019
* Program to read numbers from a file
*/

namespace M3HW2_Reaganb8472_FileReader
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Mommy?  Where did I put my random numbers?");
            Console.WriteLine("\nYou left them in your text file, dear.");
            Console.WriteLine("\nWhere is my text file, Momma?");
            Console.WriteLine("\nI don't know.  Probably somewhere in your room.  If you cleaned your room more often, " +
                "it would be easier to find.");

            bool program = true;
            bool search = false;

            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Search your room for your text file.");
                if (search)
                { 
                    Console.WriteLine("2. Open up your text file.");
                }
                Console.WriteLine("3. Go outside.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        search = Room.Search(search);
                        break;
                    case "2":
                        Room.ReadText();
                        break;
                    case "3":
                        Console.WriteLine("Moooom!  Can I go outside?");
                        Console.ReadLine();
                        program = false;
                        break;
                    default:
                        Console.WriteLine("Huh?");
                        break;
                }
            }
        }
    }
}
