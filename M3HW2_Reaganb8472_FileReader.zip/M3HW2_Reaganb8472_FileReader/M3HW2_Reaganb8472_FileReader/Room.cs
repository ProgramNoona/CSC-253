﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M3HW2_Reaganb8472_FileReader
{
    public class Room
    {
        public static bool Search (bool search)
        {
            var random = new Random();
            int findings = random.Next(5);
            bool found = false;

            switch (findings)
            {
                case 0:
                    Console.WriteLine("You search your room and find an old copy of Where's Waldo.  You sit for " +
                        "several minutes searching the pages.");
                    break;
                case 1:
                    Console.WriteLine("You find an old dolly and consult her on where to find your missing text file.  She does not reply, " +
                        "but you lift your eyes, and behold, there it is.");
                    found = true;
                    break;
                case 2:
                    Console.WriteLine("You find your backpack and your homework awaiting you.  You stare at the books for a minute and think " +
                        "about that annoying boy in your class and his Power Ranger toys.");
                    break;
                case 3:
                    Console.WriteLine("You forget that you are searching for something and instead pretend to be a ballerina. You stumble " +
                        "on the text file by accident.");
                    found = true;
                    break;
                case 4:
                    Console.WriteLine("You struggle to find your text file, get annoyed, and then pout in a pile of stuffed animals.  " +
                        "Then you find a quarter under your teddy bear, and it cheers you up.  This motivates you to find your text file.");
                    found = true;
                    break;
                default:
                    Console.WriteLine("Congratulations on breaking the program.");
                    break;
            }
            search = found;
            return search;
        }

        public static void ReadText()
        {
            int countLine = 0;
            try
            {
                string readingText;

                StreamReader inputFile;
                inputFile = File.OpenText("random_numbers.txt");
                
                while (!inputFile.EndOfStream)
                {
                    readingText = inputFile.ReadLine();
                    Console.Write($"{readingText} ");
                    countLine += 1;
                }

                inputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}
