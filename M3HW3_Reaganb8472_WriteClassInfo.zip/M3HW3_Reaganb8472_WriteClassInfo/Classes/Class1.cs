﻿using System;

namespace Classes
{
    public class Person
    {
        private string _firstName;
        private string _lastName;
        private int _age;

        public Person()
        {
            FirstName = null;
            LastName = null;
            Age = 0;
        }

        public Person(string refNum, string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
    }
}
