﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW3_Reaganb8472_WriteClassInfo
{
    public class Function
    {
        public static Classes.Person InputPerson()
        {
            int ageDoof = 0;

            Classes.Person output = new Classes.Person();

            Console.Write("What is this person's first name?  ");
            output.FirstName = Console.ReadLine();
            Console.Write("What is this person's family name?  ");
            output.LastName = Console.ReadLine();
            Console.Write("How old is this person?  ");
            while (!int.TryParse(Console.ReadLine(), out ageDoof))
            {
                Console.WriteLine("\nThat is not a number.");
                Console.Write("\nHow old is the person?  ");
            }
            output.Age = ageDoof;



            return output;
        }
    }
}
