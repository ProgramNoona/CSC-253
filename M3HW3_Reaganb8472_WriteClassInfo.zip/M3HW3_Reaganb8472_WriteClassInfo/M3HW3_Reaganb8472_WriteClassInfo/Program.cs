﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Classes;
using System.IO;

/**
* Bethany Reagan
* CSC 253
* October 3, 2019
* Program to create a person class and save it to file
*/

namespace M3HW3_Reaganb8472_WriteClassInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;

            Classes.Person person = new Classes.Person();
            List<Classes.Person> people = new List<Classes.Person>();

            Console.WriteLine("Hello, Maureen.");
            Console.WriteLine("I missed you.");
            Console.ReadLine();

            Console.WriteLine("Indeed, I would like to get to know some people.  I'm feeling quite" +
                "lonely since you left.  Would you be a dear and introduce me to some people?  I don't mean " +
                "them any harm.  I just...want to sell them some Avon products.");
            Console.WriteLine("Or I could just sell you some Avon.");

            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Input person.");
                Console.WriteLine("2. Save person to file.");
                Console.WriteLine("3. Casually browse Avon products and make an excuse to leave.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        person = Function.InputPerson();
                        people.Add(person);
                        break;
                    case "2":
                        if (person.FirstName == null)
                        {
                            Console.WriteLine("\nYou haven't entered anyone yet.");
                        }
                        else
                        {
                            Console.WriteLine("\nSaving the information to file...");

                            StreamWriter outfile;
                            outfile = File.CreateText("person.txt");

                            outfile.WriteLine($"{person.FirstName} {person.LastName} {person.Age}");
                            outfile.Close();
                        }
                        break;
                    case "3":
                        program = false;
                        Console.WriteLine("Alright, would you like to start with the lotions, or perhaps a gift " +
                            "for your mother?  ...Oh, you have to meet your mother?  Alright then... see you later.");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Incorrect Input");
                        break;
                }
            }
        }
    }
}
