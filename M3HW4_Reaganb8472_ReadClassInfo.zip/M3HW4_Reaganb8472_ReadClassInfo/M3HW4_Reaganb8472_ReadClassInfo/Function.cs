﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M3HW4_Reaganb8472_ReadClassInfo
{
    class Function
    {
        public static bool Search(bool search)
        {
            var random = new Random();
            int findings = random.Next(5);
            bool found = false;

            switch (findings)
            {
                case 0:
                    Console.WriteLine("\nYou search the bathroom cabinet, because you never know where this guy hides his things.  Turns" +
                        "out, not the bathroom.");
                    Console.ReadLine();
                    break;
                case 1:
                    Console.WriteLine("\nYou search the dining room and find the list.  It's over at the head of the table, spotted with gravy.");
                    Console.ReadLine();
                    found = true;
                    break;
                case 2:
                    Console.WriteLine("\nYou search the kitchen, but then you find the cookies he's been hiding on you.  You hide in the " +
                        "pantry to keep him from taking them away from you while you eat.");
                    Console.ReadLine();
                    break;
                case 3:
                    Console.WriteLine("\nYou search the den.  After watching a show about people building a house, you notice that the list is " +
                        "under the copy of \'Major Payne\'.");
                    found = true;
                    Console.ReadLine();
                    break;
                case 4:
                    Console.WriteLine("\nYou refuse to search the bedroom.  Absolutely not.  You consider hiding in the hall closet so that " +
                        "he can't make you, but once you open the door, you see the list sticking out of the pocket of his jacket.");
                    found = true;
                    break;
                default:
                    Console.WriteLine("Congratulations on breaking the program.");
                    break;
            }
            search = found;
            return search;
        }

        public static void ReadText()
        {
            int countLine = 0;
            try
            {
                string readingText;

                StreamReader inputFile;
                inputFile = File.OpenText("person.txt");

                while (!inputFile.EndOfStream)
                {
                    readingText = inputFile.ReadLine();
                    Console.Write($"{readingText} ");
                    countLine += 1;
                }

                inputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
