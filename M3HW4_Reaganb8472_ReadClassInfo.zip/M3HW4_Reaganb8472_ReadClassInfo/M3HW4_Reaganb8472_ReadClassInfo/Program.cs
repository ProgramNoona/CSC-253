﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW4_Reaganb8472_ReadClassInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;
            bool search = false;

            Console.WriteLine("Hey, Maureen?  Would you please find my list of...ah, Avon customers?");

            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Search for the people list.");
                if (search)
                {
                    Console.WriteLine("2. Open up the people list.");
                }
                Console.WriteLine("3. Run away while he's distracted.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        search = Function.Search(search);
                        break;
                    case "2":
                        Console.WriteLine();
                        Function.ReadText();
                        Console.WriteLine();
                        break;
                    case "3":
                        if (!search)
                        {
                            Console.WriteLine("\nMaureen!  My list!");
                            break;
                        }
                        else
                        {
                            Console.WriteLine("He's studying the list and muttering to himself.  You sneak out of the room, " +
                                "then run for the door.");
                            Console.ReadLine();
                            program = false;
                            break;
                        }
                    default:
                        Console.WriteLine("Huh?");
                        break;
                }
            }
        }
    }
}
