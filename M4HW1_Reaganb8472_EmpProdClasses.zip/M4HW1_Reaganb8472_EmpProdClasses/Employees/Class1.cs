﻿using System;

namespace Employees
{
    public class Employee
    {
        private string _name;
        private string _number;

        public Employee(string name, string number)
        {
            _name = name;
            _number = number;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Number
        {
            get { return _number; }
            set { _number = value; }
        }


    }

    public class ProductionWorker : Employee
    {
        private int _shift;
        private decimal _payRate;

        public ProductionWorker(string name, string number, int shift, decimal payRate) : base("Production Worker", "123")
        {
            Name = name;
            Number = number;
            Shift = shift;
            PayRate = payRate;
        }

        public int Shift
        {
            get { return _shift; }
            set { _shift = value; }
        }

        public decimal PayRate
        {
            get { return _payRate; }
            set { _payRate = value; }
        }
    }
}
