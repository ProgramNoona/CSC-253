﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employees;

/**
* Bethany Reagan
* CSC 253
* October 24, 2019
* Program creating a production worker class
*/

namespace M4HW1_Reaganb8472_EmpProdClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello.  I have no idea what I'm doing.  In that spirit, let us continue.");
            Console.ReadLine();

            List<Employee> workers = new List<Employee>();

            bool program = true;
            string name;
            string number;
            int shift;
            decimal payRate;

            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Enter an employee.");
                Console.WriteLine("2. Print list of employees.");
                Console.WriteLine("3. Exit.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write("Please enter the name of the employee:  ");
                        name = Console.ReadLine();
                        Console.Write("Enter the employee's employment number:  ");
                        number = Console.ReadLine();
                        Console.Write("Does the employee work on shift 1 or shift 2? (Type 1 or 2):  ");
                        while (!int.TryParse(Console.ReadLine(), out shift))
                        {
                            Console.Write("Does the employee work on shift 1 or shift 2? (Type 1 or 2):  ");
                        }
                        Console.Write("State the hourly payrate of the production employee:  ");
                        while (!decimal.TryParse(Console.ReadLine(), out payRate))
                        {
                            Console.Write("State the hourly payrate of the production employee:  ");
                        }

                        workers.Add(new ProductionWorker(name, number, shift, payRate));
                        break;
                    case "2":
                        if (workers.Count() == 0)
                        {
                            Console.WriteLine("\nYou haven't entered any workers yet.");
                            break;
                        }
                        else
                        {
                            Console.WriteLine();
                            foreach(ProductionWorker emp in workers)
                            {
                                Console.WriteLine($"Name:  {emp.Name}");
                                Console.WriteLine($"Number:  {emp.Number}");
                                Console.WriteLine($"Shift:  {emp.Shift}");
                                Console.WriteLine($"Payrate:  {emp.PayRate}");
                            }
                            Console.WriteLine();
                        }
                        break;
                    case "3":
                        program = false;
                        Console.WriteLine("Goodbye.");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Input not understood.  Please try again.");
                        break;
                }
            }
        }
    }
}
