﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employees;

/**
* Bethany Reagan
* CSC 253
* October 24, 2019
* Program adding a shift supervisor to the previous incarnation.
*/

namespace M4HW2_Reaganb8472_ShiftSup
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello.  I still have no idea what I'm doing.  This is the worst semester ever.");
            Console.WriteLine("For me, anyway.");
            Console.ReadLine();

            List<Employee> workersProd = new List<Employee>();
            List<Employee> workersSuper = new List<Employee>();

            bool program = true;
            string answer = "blah";
            

            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Enter an employee.");
                Console.WriteLine("2. Print list of employees.");
                Console.WriteLine("3. Exit.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.WriteLine("Is this -- a) a production worker, or b) a shift supervisor? (a or b)  ");
                        answer = Console.ReadLine();
                        if (answer == "a")
                        {
                            ProductionWorker worker;
                            worker = Functions.MakeProd();
                            workersProd.Add(worker);
                            break;
                        }
                        else if (answer == "b")
                        {
                            ShiftSupervisor worker;
                            worker = Functions.MakeSuper();
                            workersSuper.Add(worker);
                            break;
                        }
                        else
                        {
                            Console.WriteLine("That is not an option.\n");
                            break;
                        }
                    case "2":
                        if (workersProd.Count() != 0)
                        {
                            Console.WriteLine();
                            foreach (ProductionWorker employee in workersProd)
                            {
                                Console.WriteLine($"Name:  {employee.Name}");
                                Console.WriteLine($"Number:  {employee.Number}");
                                Console.WriteLine($"Shift:  {employee.Shift}");
                                Console.WriteLine($"Payrate:  {employee.PayRate}");
                            }
                            Console.WriteLine();
                        }
                        if (workersSuper.Count() != 0)
                        {
                            Console.WriteLine();
                            foreach (ShiftSupervisor employee in workersSuper)
                            {
                                Console.WriteLine($"Name:  {employee.Name}");
                                Console.WriteLine($"Number:  {employee.Number}");
                                Console.WriteLine($"Shift:  {employee.Shift}");
                                Console.WriteLine($"Yearly Salary:  {employee.Salary}");
                            }
                            Console.WriteLine();
                        }
                        break;
                    case "3":
                        program = false;
                        Console.WriteLine("Goodbye.");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Input not understood.  Please try again.");
                        break;
                }
            }
        }
    }
}