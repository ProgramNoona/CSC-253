﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employees;

namespace M4HW3_Reaganb8472_TeamLeader
{
    class Functions
    {
        public static ProductionWorker MakeProd()
        {
            ProductionWorker worker;
            string name;
            string number;
            int shift;
            decimal payRate;

            Console.Write("Please enter the name of the employee:  ");
            name = Console.ReadLine();
            Console.Write("Enter the employee's employment number:  ");
            number = Console.ReadLine();
            Console.Write("Does the employee work on shift 1 or shift 2? (Type 1 or 2):  ");
            while (!int.TryParse(Console.ReadLine(), out shift))
            {
                Console.Write("Does the employee work on shift 1 or shift 2? (Type 1 or 2):  ");
            }
            Console.Write("State the hourly payrate of the production employee:  ");
            while (!decimal.TryParse(Console.ReadLine(), out payRate))
            {
                Console.Write("State the hourly payrate of the production employee:  ");
            }

            worker = new ProductionWorker(name, number, shift, payRate);

            return worker;
        }

        public static ShiftSupervisor MakeSuper()
        {
            ShiftSupervisor worker;
            string name;
            string number;
            int shift;
            int salary;

            Console.Write("Please enter the name of the employee:  ");
            name = Console.ReadLine();
            Console.Write("Enter the employee's employment number:  ");
            number = Console.ReadLine();
            Console.Write("Does the employee work on shift 1 or shift 2? (Type 1 or 2):  ");
            while (!int.TryParse(Console.ReadLine(), out shift))
            {
                Console.Write("Does the employee work on shift 1 or shift 2? (Type 1 or 2):  ");
            }
            Console.Write("State the yearly salary of the shift supervisor:  ");
            while (!int.TryParse(Console.ReadLine(), out salary))
            {
                Console.Write("State the hourly payrate of the production employee:  ");
            }

            worker = new ShiftSupervisor(name, number, shift, salary);

            return worker;
        }

        public static TeamLeader MakeTeam()
        {
            TeamLeader worker;
            string name;
            string number;
            decimal payRate;
            int bonus;
            int hoursReq;
            int hoursAttend;

            Console.Write("Please enter the name of the employee:  ");
            name = Console.ReadLine();
            Console.Write("Enter the employee's employment number:  ");
            number = Console.ReadLine();
            Console.Write("State the the employee's hourly pay rate:  ");
            while (!decimal.TryParse(Console.ReadLine(), out payRate))
            {
                Console.Write("State the the employee's hourly pay rate:  ");
            }
            Console.Write("State the monthly bonus of the team leader:  ");
            while (!int.TryParse(Console.ReadLine(), out bonus))
            {
                Console.Write("State the monthly bonus of the team leader:  ");
            }
            Console.WriteLine("State the hours of training required for the team leader:  ");
            while (!int.TryParse(Console.ReadLine(), out hoursReq))
            {
                Console.WriteLine("State the hours of training required for the team leader:  ");
            }
            Console.WriteLine("State the hours of training attended by the team leader:  ");
            while (!int.TryParse(Console.ReadLine(), out hoursAttend))
            {
                Console.WriteLine("State the hours of training attended by the team leader:  ");
            }

            worker = new TeamLeader(name, number, payRate, bonus, hoursReq, hoursAttend);

            return worker;
        }
    }
}
