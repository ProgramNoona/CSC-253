﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employees;

/**
* Bethany Reagan
* CSC 253
* October 24, 2019
* Program adding a shift supervisor to the previous incarnation.
*/

namespace M4HW3_Reaganb8472_TeamLeader
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello.  I still have no idea what I'm doing, but I'm pretty sure that everything is going to be alright.");
            Console.WriteLine("For me, anyway.");
            Console.ReadLine();

            List<Employee> workersProd = new List<Employee>();
            List<Employee> workersSuper = new List<Employee>();
            List<Employee> workersTL = new List<Employee>();

            bool program = true;
            string answer = "blah";


            while (program)
            {
                Console.WriteLine("\nSelect a choice below --- ");
                Console.WriteLine("1. Enter an employee.");
                Console.WriteLine("2. Print list of employees.");
                Console.WriteLine("3. Exit.");
                Console.Write("Pick a choice... ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.WriteLine("Is this -- a) a production worker, b) a shift supervisor, or c) a Team Leader? (a, b, or c)  ");
                        answer = Console.ReadLine();
                        if (answer == "a")
                        {
                            ProductionWorker worker;
                            worker = Functions.MakeProd();
                            workersProd.Add(worker);
                            break;
                        }
                        else if (answer == "b")
                        {
                            ShiftSupervisor worker;
                            worker = Functions.MakeSuper();
                            workersSuper.Add(worker);
                            break;
                        }
                        else if (answer == "c")
                        {
                            TeamLeader worker;
                            worker = Functions.MakeTeam();
                            workersTL.Add(worker);
                            break;
                        }
                        else
                        {
                            Console.WriteLine("That is not an option.\n");
                            break;
                        }
                    case "2":
                        if (workersProd.Count() != 0)
                        {
                            Console.WriteLine();
                            foreach (ProductionWorker employee in workersProd)
                            {
                                Console.WriteLine($"Name:  {employee.Name}");
                                Console.WriteLine($"Number:  {employee.Number}");
                                Console.WriteLine($"Shift:  {employee.Shift}");
                                Console.WriteLine($"Payrate:  {employee.PayRate}");
                            }
                            Console.WriteLine();
                        }
                        if (workersSuper.Count() != 0)
                        {
                            Console.WriteLine();
                            foreach (ShiftSupervisor employee in workersSuper)
                            {
                                Console.WriteLine($"Name:  {employee.Name}");
                                Console.WriteLine($"Number:  {employee.Number}");
                                Console.WriteLine($"Shift:  {employee.Shift}");
                                Console.WriteLine($"Yearly Salary:  {employee.Salary}");
                            }
                            Console.WriteLine();
                        }
                        if (workersTL.Count() != 0)
                        {
                            Console.WriteLine();
                            foreach (TeamLeader employee in workersSuper)
                            {
                                Console.WriteLine($"Name:  {employee.Name}");
                                Console.WriteLine($"Number:  {employee.Number}");
                                Console.WriteLine($"Pay Rate:  {employee.PayRate}");
                                Console.WriteLine($"Monthly Bonus:  {employee.Bonus}");
                                Console.WriteLine($"Hours of Training Required:  {employee.HoursReq}");
                                Console.WriteLine($"Hours of Training Attended:  {employee.HoursAttend}");
                            }
                            Console.WriteLine();
                        }
                        break;
                    case "3":
                        program = false;
                        Console.WriteLine("Goodbye.");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Input not understood.  Please try again.");
                        break;
                }
            }
        }
    }
}