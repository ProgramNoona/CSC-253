﻿using System;

namespace RetailLibrary
{
    public class Retail
    {
        public static string GetName()
        {
            Console.WriteLine("What is the name of your product?");
            return Console.ReadLine();
        }

        public static decimal SetWholesale(decimal price)
        {
            Console.Write("What is the wholesale price?  ");
            while (!decimal.TryParse(Console.ReadLine(), out price))
            {
                Console.Write("That is not a number.");
            }
            return price;
        }

        public static decimal SetMarkup(decimal percent)
        {
            Console.Write("What is the markup percentage?  ");
            while (!decimal.TryParse(Console.ReadLine(), out percent))
            {
                Console.Write("That is not a number.");
            }

            return percent;
        }
    }
}
