﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLibrary;

/**
* Bethany Reagan
* CSC 153
* November 7, 2019
* M5 Retail Price Calculator with Unit Test
*/

namespace RetailPriceCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Unnamed Product";
            decimal wholesale = 0.0m;
            decimal markup = 0.0m;
            bool program = true;

            do
            {
                Console.WriteLine("Please choose an option: ");
                Console.WriteLine("1. Enter a name for the product.");
                Console.WriteLine("2. Enter the product's wholesale price.");
                Console.WriteLine("3. Enter the markup percentage.");
                Console.WriteLine("4. Display the product's retail price.");
                Console.WriteLine("5. Exit.");
                Console.Write("Option#: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        name = Retail.GetName();
                        Console.WriteLine($"You have entered the name {name}.\n");
                        break;
                    case "2":
                        wholesale = Retail.SetWholesale(wholesale);
                        Console.WriteLine($"You have set the wholesale price as {wholesale}.\n");
                        break;
                    case "3":
                        markup = Retail.SetMarkup(markup);
                        Console.WriteLine($"You have set the markup as {markup}.\n");
                        markup += 1.0m;
                        break;
                    case "4":
                        if (wholesale == 0.0m)
                        {
                            Console.WriteLine("You haven't set the wholesale price.\n");
                        }
                        else if (markup == 0.0m)
                        {
                            Console.WriteLine("You haven't set the markup percentage.\n");
                        }
                        else
                        {
                            decimal retail = markup * wholesale;
                            markup -= 1m;
                            string wholesalePrice = String.Format("{0:C}", wholesale);
                            string retailPrice = String.Format("{0:C}", retail);
                            Console.WriteLine($"At {wholesalePrice} and with a {markup} markup, {name} costs {retailPrice} on the shelf.\n");
                        }
                        break;
                    case "5":
                        program = false;
                        break;
                    default:
                        Console.WriteLine("That was not a choice.\n");
                        break;
                }
            } while (program == true);

            Console.WriteLine("\"Knowledge is dead\" \n\t-- Albert Einstein.");
            Console.ReadLine();
        }

        
    }
}
