﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using RetailLibrary;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace UnitTestProjectRPC
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void NotNullValues_Wholesale([Values(0)] decimal input)
        {
            string warning = "Input must be a value greater than zero.";
            decimal output = Retail.SetWholesale(input);
            Assert.IsTrue(input > 0.0m, warning);
        }

        [Test]
        public void NotNullValues_Markup([Values(0)] decimal input)
        {
            string warning = "Input must be a value greater than zero.";
            decimal output = Retail.SetMarkup(input);
            Assert.IsTrue(input > 0.0m, warning);
        }
    }
}
