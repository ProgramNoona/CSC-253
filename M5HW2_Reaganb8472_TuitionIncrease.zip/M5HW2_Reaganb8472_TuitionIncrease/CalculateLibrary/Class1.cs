﻿using System;

namespace CalculateLibrary
{
    public class Calculate
    {
        public static void FindTuition(decimal tuition, decimal increase, decimal years)
        {
            for (int i = 0; i < years; i++)
            {
                tuition += tuition * increase;
                string tuitionFormat = String.Format("{0:C}", tuition);
                Console.WriteLine($"For year {i}, the tuition is {tuitionFormat}.");
            }
        }
    }
}
