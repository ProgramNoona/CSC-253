﻿/**
* Bethany Reagan
* CSC 153
* February 18, 2018
* Tuition Increase -- Calculates the increase of tuition over a period of five years.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculateLibrary;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Tuition Increase program, Maureen, created specifically to raise the " +
            "blood pressure of every student in the next five years.");
            Console.WriteLine("That is to say, tuition is going to increase 2% every year for the next five years.");
            Console.WriteLine("That doesn't sound like much, does it?  But let us calculate.");

            decimal origTuition = 6000m;
            decimal increase = 0.02m;
            decimal years = 5.0m;
            string origTuit = String.Format("{0:C}", origTuition);

            Console.WriteLine($"The original tuition for the semester is {origTuit}.");

            decimal tuition = origTuition;

            Calculate.FindTuition(tuition, increase, years);
            Console.WriteLine("\nGood luck paying for school, my dear!");
            Console.ReadLine();
        }
    }
}