﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TuitionTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void FinalTotal(decimal input)
        {
            double finalTuition = 6624.48;
            string output = Calculate.FindTuition.input();
            Assert.AreEqual(finalTuition, output);
        }
    }
}
