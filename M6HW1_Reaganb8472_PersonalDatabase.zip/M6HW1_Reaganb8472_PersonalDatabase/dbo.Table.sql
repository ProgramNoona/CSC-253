﻿CREATE TABLE [dbo].[Table]
(
	[EmployeeId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] VARCHAR(50) NOT NULL, 
    [Position] VARCHAR(50) NOT NULL, 
    [Hourly Pay Rate] MONEY NOT NULL
)
