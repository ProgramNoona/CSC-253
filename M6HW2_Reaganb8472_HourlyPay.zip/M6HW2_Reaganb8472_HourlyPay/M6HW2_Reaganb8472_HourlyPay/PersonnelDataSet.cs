﻿namespace M6HW2_Reaganb8472_HourlyPay
{


    partial class PersonnelDataSet
    {
    }
}

namespace M6HW2_Reaganb8472_HourlyPay.PersonnelDataSetTableAdapters {
    
    
    public partial class TableTableAdapter {
    }
}
