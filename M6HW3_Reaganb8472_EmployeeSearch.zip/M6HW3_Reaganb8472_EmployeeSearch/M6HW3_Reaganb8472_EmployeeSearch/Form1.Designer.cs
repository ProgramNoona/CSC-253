﻿namespace M6HW3_Reaganb8472_EmployeeSearch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label employeeIdLabel;
            System.Windows.Forms.Label positionLabel;
            System.Windows.Forms.Label hourly_Pay_RateLabel;
            this.EmployeeSearchListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.personnelDataSet = new M6HW3_Reaganb8472_EmployeeSearch.PersonnelDataSet();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter = new M6HW3_Reaganb8472_EmployeeSearch.PersonnelDataSetTableAdapters.TableTableAdapter();
            this.tableAdapterManager = new M6HW3_Reaganb8472_EmployeeSearch.PersonnelDataSetTableAdapters.TableAdapterManager();
            this.employeeIdTextBox = new System.Windows.Forms.TextBox();
            this.positionTextBox = new System.Windows.Forms.TextBox();
            this.hourly_Pay_RateTextBox = new System.Windows.Forms.TextBox();
            employeeIdLabel = new System.Windows.Forms.Label();
            positionLabel = new System.Windows.Forms.Label();
            hourly_Pay_RateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.personnelDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // EmployeeSearchListBox
            // 
            this.EmployeeSearchListBox.DataSource = this.tableBindingSource;
            this.EmployeeSearchListBox.DisplayMember = "Name";
            this.EmployeeSearchListBox.FormattingEnabled = true;
            this.EmployeeSearchListBox.Location = new System.Drawing.Point(44, 64);
            this.EmployeeSearchListBox.Name = "EmployeeSearchListBox";
            this.EmployeeSearchListBox.Size = new System.Drawing.Size(120, 95);
            this.EmployeeSearchListBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Search for Employee";
            // 
            // personnelDataSet
            // 
            this.personnelDataSet.DataSetName = "PersonnelDataSet";
            this.personnelDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.personnelDataSet;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TableTableAdapter = this.tableTableAdapter;
            this.tableAdapterManager.UpdateOrder = M6HW3_Reaganb8472_EmployeeSearch.PersonnelDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // employeeIdLabel
            // 
            employeeIdLabel.AutoSize = true;
            employeeIdLabel.Location = new System.Drawing.Point(204, 60);
            employeeIdLabel.Name = "employeeIdLabel";
            employeeIdLabel.Size = new System.Drawing.Size(68, 13);
            employeeIdLabel.TabIndex = 2;
            employeeIdLabel.Text = "Employee Id:";
            // 
            // employeeIdTextBox
            // 
            this.employeeIdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tableBindingSource, "EmployeeId", true));
            this.employeeIdTextBox.Location = new System.Drawing.Point(297, 57);
            this.employeeIdTextBox.Name = "employeeIdTextBox";
            this.employeeIdTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeIdTextBox.TabIndex = 3;
            // 
            // positionLabel
            // 
            positionLabel.AutoSize = true;
            positionLabel.Location = new System.Drawing.Point(204, 102);
            positionLabel.Name = "positionLabel";
            positionLabel.Size = new System.Drawing.Size(47, 13);
            positionLabel.TabIndex = 4;
            positionLabel.Text = "Position:";
            // 
            // positionTextBox
            // 
            this.positionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tableBindingSource, "Position", true));
            this.positionTextBox.Location = new System.Drawing.Point(297, 99);
            this.positionTextBox.Name = "positionTextBox";
            this.positionTextBox.Size = new System.Drawing.Size(100, 20);
            this.positionTextBox.TabIndex = 5;
            // 
            // hourly_Pay_RateLabel
            // 
            hourly_Pay_RateLabel.AutoSize = true;
            hourly_Pay_RateLabel.Location = new System.Drawing.Point(204, 146);
            hourly_Pay_RateLabel.Name = "hourly_Pay_RateLabel";
            hourly_Pay_RateLabel.Size = new System.Drawing.Size(87, 13);
            hourly_Pay_RateLabel.TabIndex = 6;
            hourly_Pay_RateLabel.Text = "Hourly Pay Rate:";
            // 
            // hourly_Pay_RateTextBox
            // 
            this.hourly_Pay_RateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tableBindingSource, "Hourly Pay Rate", true));
            this.hourly_Pay_RateTextBox.Location = new System.Drawing.Point(297, 143);
            this.hourly_Pay_RateTextBox.Name = "hourly_Pay_RateTextBox";
            this.hourly_Pay_RateTextBox.Size = new System.Drawing.Size(100, 20);
            this.hourly_Pay_RateTextBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 254);
            this.Controls.Add(hourly_Pay_RateLabel);
            this.Controls.Add(this.hourly_Pay_RateTextBox);
            this.Controls.Add(positionLabel);
            this.Controls.Add(this.positionTextBox);
            this.Controls.Add(employeeIdLabel);
            this.Controls.Add(this.employeeIdTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EmployeeSearchListBox);
            this.Name = "Form1";
            this.Text = "Employee Lookup";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.personnelDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox EmployeeSearchListBox;
        private System.Windows.Forms.Label label1;
        private PersonnelDataSet personnelDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private PersonnelDataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private PersonnelDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox employeeIdTextBox;
        private System.Windows.Forms.TextBox positionTextBox;
        private System.Windows.Forms.TextBox hourly_Pay_RateTextBox;
    }
}

