﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW4_Reaganb8472_PopulationDatabase
{
    public partial class Population : Form
    {
        public Population()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void cityBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Population_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationAscending(this.populationDBDataSet.City);
        }

        private void cityBindingSource1BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource1.EndEdit();
            this.tableAdapterManager1.UpdateAll(this.populationDBDataSet1);

        }

        private void Population_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet1.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter1.Fill(this.populationDBDataSet1.City);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationDescending(this.populationDBDataSet.City);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByCity(this.populationDBDataSet.City);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            double totalPop;

            totalPop = (double) this.cityTableAdapter.TotalPopulation();

            MessageBox.Show("Total Population of Listed Cities:  " + totalPop.ToString());
        }

        private void button9_Click(object sender, EventArgs e)
        {
            double avePop;

            avePop = (double)this.cityTableAdapter.AveragePopulation();

            MessageBox.Show("Average Population of Listed Cities:  " + avePop.ToString());
        }

        private void button10_Click(object sender, EventArgs e)
        {
            double maxPop;

            maxPop = (double)this.cityTableAdapter.MaxPopulation();

            MessageBox.Show("City with Largest Population:  " + maxPop.ToString());
        }

        private void button11_Click(object sender, EventArgs e)
        {
            double minPop;

            minPop = (double)this.cityTableAdapter.MaxPopulation();

            MessageBox.Show("City with Smallest Population:  " + minPop.ToString());
        }
    }
}
