﻿namespace M6HW4_Reaganb8472_PopulationDatabase
{


    partial class PopulationDBDataSet
    {
    }
}

namespace M6HW4_Reaganb8472_PopulationDatabase.PopulationDBDataSetTableAdapters {
    
    
    public partial class CityTableAdapter {
    }
}
